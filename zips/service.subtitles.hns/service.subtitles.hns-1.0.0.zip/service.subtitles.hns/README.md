# HNS Subtitles - Kodi Subtitle Addon

Kodi subtitle service addon for hns.sk — Czech and Slovak anime subtitles from several fansub groups.

Compatible with Kodi 19, 20, and 21.

## Current Version
service.subtitles.hns - 1.0.0

## Installation Instructions
Recommended: install through the [Highflight Subtitles Repository](https://github.com/KiritoSenpaiCZ/KiritoSenpaiCZ.github.io), which also handles updates.

Manual install:
1. Download `service.subtitles.hns-1.0.0.zip` from this repo (or build it from source)
2. In Kodi: **Add-ons > Install from zip file**, select the zip

## Setup Instructions
1. In Kodi, open this addon's settings
2. Enter the e-mail and password of your hns.sk account (hns.sk logs in by e-mail, not by nickname)

## How it works
- Messages and settings are in Czech when Kodi is set to Czech or Slovak, and in English otherwise
- Matches the show title from Kodi's video metadata (or a manual search, or the file name) against hns.sk's anime list, picking the right season where the site lists seasons separately
- When the season isn't known and several shows match, results from each are listed with the show's name, so you can tell them apart
- Lists every release of the episode (e.g. SubsPlease 1080p, Erai-raws 720p) with its translator and version, so you can pick the one matching your video
- hns.sk doesn't say whether a subtitle is Czech or Slovak, so results are marked `[CZ/SK]` and listed under Czech (or Slovak, if that's the only one of the two in Kodi's subtitle languages)
- Stays logged in between searches (the login is kept in the addon's profile folder) and only logs in again when the site asks for it
- The site's anime list is cached for 24 hours
- Downloaded files are validated before use (rejects HTML error pages and oversized responses) and old temp files are swept automatically

## Issues
Please open an issue in this repo with a description of the problem and, if possible, a Kodi debug log (Settings > System > Logging > Enable debug logging, then grep `kodi.log` for `[HNS]`).
