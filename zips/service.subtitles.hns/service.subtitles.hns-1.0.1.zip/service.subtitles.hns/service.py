# -*- coding: utf-8 -*-
"""
HNS (hns.sk) Subtitles - Kodi subtitle service addon.

Site notes:
- hns.sk hosts Czech and Slovak anime subtitles from several fansub
  groups. The site doesn't mark which of the two languages a subtitle is
  in, so results are labelled "CZ/SK".
- Every page needs a logged-in account (login is by e-mail). A
  logged-out request is redirected to /site/login, recognisable by its
  id="login-form". The login form posts _csrf, LoginForm[email],
  LoginForm[password] and LoginForm[rememberMe]; a logged-in page has a
  /site/logout link. Session cookies are kept between runs in
  COOKIES_FILE, so a normal search doesn't log in again.
- /animelist lists every anime (slug + title) on one page. It is cached
  for 24 hours in CATALOG_FILE.
- /anime/<slug> lists all episodes. Each episode is its own table: the
  header links to /anime/episode/<slug>/<episode id> with the text
  "<title> <episode number>", and every release row holds the release
  name, translator, date, version, an optional note, and a form with the
  subtitle id and file name.
- Downloading: the forms on the show page lack the "action" field (the
  site's JavaScript adds it), so the download goes through the episode
  page instead. Its form (id, name, _csrf, action=download) is posted back
  to the episode page and the response is the subtitle file itself.

Debugging: enable Kodi's debug log (Settings -> System -> Logging),
reproduce, then look for "[HNS]" lines in kodi.log.
"""

import difflib
import html as html_mod
import json
import os
import re
import shutil
import sys
import time
import traceback
import zipfile
from urllib.parse import parse_qs, unquote

import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')

PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
TEMP_DIR = xbmcvfs.translatePath(os.path.join(PROFILE, 'temp', ''))
if not xbmcvfs.exists(TEMP_DIR):
    xbmcvfs.mkdirs(TEMP_DIR)
ROWS_FILE = os.path.join(TEMP_DIR, 'hns_rows.json')
OWNERS_FILE = os.path.join(TEMP_DIR, 'hns_owners.json')
CATALOG_FILE = os.path.join(TEMP_DIR, 'hns_catalog.json')
CATALOG_TTL = 24 * 60 * 60
# login cookies live outside TEMP_DIR so the temp sweep never touches them
COOKIES_FILE = os.path.join(PROFILE, 'hns_cookies.json')

HANDLE = int(sys.argv[1])

BASE_URL = "https://hns.sk"
LOGIN_URL = BASE_URL + "/site/login"
CATALOG_URL = BASE_URL + "/animelist"
HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                  "(KHTML, like Gecko) Chrome/124.0 Safari/537.36"
}

# Anything left behind in TEMP_DIR older than this gets swept on the next
# run - a search+download round trip finishes in well under a minute, so
# anything still there an hour later is leftover, not in-use.
TEMP_MAX_AGE_SECONDS = 3600
# temp-folder entries this addon creates start with TEMP_FILE_PREFIX;
# KEEP_FILES are never swept
TEMP_FILE_PREFIX = 'hns_'
KEEP_FILES = {os.path.basename(ROWS_FILE), os.path.basename(CATALOG_FILE), os.path.basename(OWNERS_FILE)}

# Refuse an implausibly large download - subtitle files are small, so
# hitting this means something's wrong (a huge unexpected response).
MAX_DOWNLOAD_BYTES = 20 * 1024 * 1024
MAX_EXTRACTED_BYTES = 50 * 1024 * 1024

# when the season isn't known and several shows match, this many are listed
MAX_SHOWS = 5
MAX_ITEMS = 80

SUB_EXTENSIONS = ('.ass', '.ssa', '.srt', '.sub', '.vtt')

# >>> shared block "kodi_lang" - edit dev/shared/kodi_lang.py in KiritoSenpaiCZ.github.io, then run dev/sync.py
# The addon's messages are in Czech when Kodi's language is Czech or Slovak,
# English otherwise. L("english", "czech", *args) picks one and fills in
# {0}-style placeholders like str.format.
try:
    _UI_LANG = xbmc.getLanguage(xbmc.ISO_639_1)
except Exception:
    _UI_LANG = ''


def L(en, cs, *args):
    text = cs if _UI_LANG in ('cs', 'sk') else en
    return text.format(*args) if args else text
# <<< shared block "kodi_lang"


# ---------------- small helpers ----------------

def log(msg):
    xbmc.log("[HNS] {0}".format(msg), level=xbmc.LOGDEBUG)


def notify(msg):
    xbmcgui.Dialog().notification(ADDON_NAME, msg, xbmcgui.NOTIFICATION_INFO, 4000)


def get_params():
    raw = sys.argv[2] if len(sys.argv) > 2 else ""
    return parse_qs(raw.lstrip('?'))


def save_json(path, data):
    try:
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(data, f)
    except Exception as e:
        log("failed to save {0}: {1}".format(path, e))


def load_json(path):
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return None


def strip_tags(text):
    text = re.sub(r'<[^>]+>', ' ', text or '')
    text = html_mod.unescape(text).replace('\xa0', ' ')
    return re.sub(r'\s+', ' ', text).strip()


def extract_attr(attrs, name):
    m = re.search(r'\b{0}="([^"]*)"'.format(re.escape(name)), attrs)
    return html_mod.unescape(m.group(1)) if m else None


def parse_inputs(form_html):
    fields = {}
    for attrs in re.findall(r'<input\s+([^>]*?)/?>', form_html):
        name = extract_attr(attrs, "name")
        if name:
            fields[name] = extract_attr(attrs, "value") or ""
    return fields


# >>> shared block "kodi_temp" - edit dev/shared/kodi_temp.py in KiritoSenpaiCZ.github.io, then run dev/sync.py
def current_video():
    """Path of the video Kodi has loaded - playing OR paused - else None.
    (Player.Playing alone isn't enough: it's false while paused.)"""
    try:
        if xbmc.getCondVisibility('Player.HasVideo') or xbmc.getCondVisibility('Player.Paused'):
            return xbmc.getInfoLabel('Player.Filenameandpath') or None
    except Exception:
        pass
    return None


def _read_owners():
    try:
        with open(OWNERS_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _write_owners(owners):
    try:
        with open(OWNERS_FILE, 'w', encoding='utf-8') as f:
            json.dump(owners, f)
    except Exception as e:
        log("couldn't save {0}: {1}".format(OWNERS_FILE, e))


def remember_owner(path):
    """Record which video a delivered subtitle belongs to, so
    cleanup_temp_dir() never deletes it while that video is still loaded
    (e.g. paused for more than an hour)."""
    video = current_video()
    if not video:
        return
    try:
        top = os.path.relpath(path, TEMP_DIR).split(os.sep)[0]
    except ValueError:
        return
    if not top or top.startswith('..'):
        return
    owners = _read_owners()
    owners[top] = video
    _write_owners(owners)


def cleanup_temp_dir():
    """Sweep old downloads out of TEMP_DIR. Kept: KEEP_FILES (small caches
    managed by their own logic), and every subtitle belonging to the video
    Kodi currently has loaded - playing or paused - however old it is, so a
    long pause can't delete a subtitle that's still in use."""
    keep = KEEP_FILES
    owners = _read_owners()
    video = current_video()
    try:
        now = time.time()
        for name in os.listdir(TEMP_DIR):
            if name in keep or not name.startswith(TEMP_FILE_PREFIX):
                continue
            if video and owners.get(name) == video:
                continue
            path = os.path.join(TEMP_DIR, name)
            try:
                age = now - os.path.getmtime(path)
            except OSError:
                continue
            if age < TEMP_MAX_AGE_SECONDS:
                continue
            try:
                if os.path.isdir(path):
                    shutil.rmtree(path, ignore_errors=True)
                else:
                    os.remove(path)
            except OSError as e:
                log("cleanup: couldn't remove {0}: {1}".format(path, e))
        existing = set(os.listdir(TEMP_DIR))
        still_there = dict((k, v) for k, v in owners.items() if k in existing)
        if still_there != owners:
            _write_owners(still_there)
    except Exception as e:
        log("cleanup_temp_dir failed: {0}".format(e))
# <<< shared block "kodi_temp"


# >>> shared block "kodi_titles" - edit dev/shared/kodi_titles.py in KiritoSenpaiCZ.github.io, then run dev/sync.py
def split_season_title(title):
    """Strips a season / cour ending from a show title and returns
    (base title, season or None). Players and anime addons often pass the
    full season name, e.g. "Tensei Shitara Slime Datta Ken 4th Season
    Part 1 & 2"; the site searches need every word to match, so they would
    find nothing. "Part N" (a cour split) is dropped without a season."""
    if not title:
        return title, None
    part = r'[\s:\-–]*\bpart\s*\d+(?:\s*(?:&|and|\+)\s*\d+)?\s*$'
    base = re.sub(part, '', title.strip(), flags=re.I)
    season = None
    for pattern in (r'\b(\d{1,2})(?:st|nd|rd|th)\s+season$',
                    r'\bseason\s*(\d{1,2})$',
                    r'\bs(\d{1,2})$'):
        m = re.search(r'[\s:\-–]*' + pattern, base, re.I)
        if m:
            season = int(m.group(1))
            base = base[:m.start()]
            break
    base = re.sub(part, '', base, flags=re.I)
    base = re.sub(r'[\s:\-–]+$', '', base).strip()
    return (base or title), season
# <<< shared block "kodi_titles"


# ---------------- title/query cleanup ----------------

def clean_release_title(name):
    if not name:
        return name
    name = re.sub(r'\.\w+$', '', name)
    name = re.sub(r'\[[^\]]*\]', ' ', name)
    name = re.sub(r'\([^)]*\)', ' ', name)
    name = re.sub(r'[._]', ' ', name)

    lower = name.lower()
    cut_at = None
    m = re.search(r's\d{1,2}e\d{1,2}', lower)
    if m:
        cut_at = m.start()
    keywords = [
        "2160p", "1080p", "720p", "480p", "4k",
        "blu-ray", "bluray", "bdrip", "webrip", "web-dl", "web dl",
        "hdtv", "dvdrip", "hdrip",
        "x264", "x265", "h264", "h265", "hevc", "avc",
        "dual audio", "dual-audio", "multi audio", "multi-audio",
        "aac", "flac", "dts", "opus",
    ]
    for kw in keywords:
        idx = lower.find(kw)
        if idx != -1 and (cut_at is None or idx < cut_at):
            cut_at = idx
    if cut_at is not None:
        name = name[:cut_at]

    name = re.sub(r'\s-\s*\d+.*$', '', name)
    name = re.sub(r'[-–—]+\s*$', '', name)
    name = re.sub(r'\s+', ' ', name).strip()
    return name


def parse_video_name(text):
    """Splits a file name or typed search into (title, season, episode).
    Understands "Show S02E05" as well as anime-style "Show S2 - 05",
    "Show 2nd Season - 05" and "Show - 05"; season and episode are None
    when not present."""
    if not text:
        return text, None, None
    season = episode = None
    m = re.search(r'[sS](\d{1,2})[eE](\d{1,4})', text)
    if m:
        season, episode = int(m.group(1)), int(m.group(2))
        text = (text[:m.start()] + text[m.end():]).strip()
    else:
        plain = re.sub(r'\[[^\]]*\]|\([^)]*\)', ' ', text)
        m = re.search(r'\s-\s*(\d{1,4})(?:v\d+)?(?=[\s._\[(]|$)', plain)
        if m:
            episode = int(m.group(1))
    title = clean_release_title(text) or text
    m = re.search(r'\s+(?:s|season\s*)(\d{1,2})$', title, re.I) or \
        re.search(r'\s+(\d{1,2})(?:st|nd|rd|th)\s+season$', title, re.I)
    if m:
        if season is None:
            season = int(m.group(1))
        title = title[:m.start()].strip()
    return title, season, episode


def normalize(text):
    text = html_mod.unescape(text or '').lower()
    text = re.sub(r'[^\w]+', ' ', text, flags=re.UNICODE)
    return re.sub(r'\s+', ' ', text).strip()


ROMAN = {'ii': 2, 'iii': 3, 'iv': 4, 'v': 5, 'vi': 6}


def title_remainder(query_norm, title_norm):
    """What a catalog title adds to the searched title, e.g. "2" for
    "Grand Blue 2" when searching "Grand Blue"."""
    if title_norm.startswith(query_norm):
        return title_norm[len(query_norm):].strip()
    query_words = set(query_norm.split())
    return ' '.join(w for w in title_norm.split() if w not in query_words)


def remainder_season(rest):
    """Season number a title remainder stands for: 1 when there's
    nothing extra, None when it's extra words without a season marker
    (a spin-off, a movie...)."""
    if not rest:
        return 1
    m = (re.match(r'(?:season|s)\s*(\d{1,2})\b', rest) or
         re.match(r'(\d{1,2})(?:st|nd|rd|th) season\b', rest) or
         re.match(r'(\d{1,2})\b', rest))
    if m:
        return int(m.group(1))
    m = re.match(r'(ii|iii|iv|v|vi)\b', rest)
    if m:
        return ROMAN[m.group(1)]
    return None


def choose_shows(query, season, shows):
    """Returns the catalog entries to list, best first. With a known
    season this is normally one show; otherwise, when several titles
    match, up to MAX_SHOWS of them (each result is labelled with its
    show title, so the season stays visible)."""
    query_norm = normalize(query)
    if not query_norm:
        return []
    words = query_norm.split()
    found = []
    for show in shows:
        title_norm = normalize(show['title'])
        padded = ' {0} '.format(title_norm)
        if all(' {0} '.format(w) in padded for w in words):
            found.append(show)
    if not found:
        titles = [normalize(s['title']) for s in shows]
        close = difflib.get_close_matches(query_norm, titles, n=MAX_SHOWS, cutoff=0.6)
        found = [shows[titles.index(c)] for c in close]
        log("no title contains all words of '{0}', closest: {1}".format(
            query, [s['title'] for s in found]))
        return found[:1] if season else found

    scored = []
    for show in found:
        rest = title_remainder(query_norm, normalize(show['title']))
        scored.append((show, rest, remainder_season(rest)))
    # exact title first, then numbered seasons in order, then the rest
    scored.sort(key=lambda x: (x[2] is None, x[2] or 0, len(x[1]), x[0]['title']))

    if season:
        same = [x for x in scored if x[2] == season]
        if same:
            return [same[0][0]]
        if season == 1:
            # "Show: Subtitle" without a season marker is season 1 when the
            # bare title isn't in the catalog
            unmarked = [x[0] for x in scored if x[2] is None]
            if unmarked:
                return unmarked[:MAX_SHOWS]
        log("no title for season {0} among {1} match(es)".format(season, len(scored)))
    return [x[0] for x in scored[:MAX_SHOWS]]


def get_allowed_languages(params):
    raw = params.get('languages', [''])[0]
    if not raw:
        return None
    return set(unquote(n) for n in raw.split(','))


def pick_language(allowed):
    """The site mixes Czech and Slovak without saying which is which, so
    results are listed under whichever of the two Kodi asked for."""
    if not allowed or 'Czech' in allowed:
        return "Czech", "cs"
    if 'Slovak' in allowed:
        return "Slovak", "sk"
    return None, None


# ---------------- site access ----------------

class LoginFailed(Exception):
    pass


def is_login_page(text):
    return 'id="login-form"' in (text or '')


def new_session(email):
    session = requests.Session()
    session.headers.update(HEADERS)
    saved = load_json(COOKIES_FILE)
    if saved and saved.get('email') == email:
        for c in saved.get('cookies', []):
            try:
                session.cookies.set(c['name'], c['value'], domain=c.get('domain', ''), path=c.get('path', '/'))
            except Exception:
                pass
    return session


def save_session(session, email):
    cookies = [{"name": c.name, "value": c.value, "domain": c.domain, "path": c.path}
               for c in session.cookies]
    save_json(COOKIES_FILE, {"email": email, "cookies": cookies})


def login(session, email, password):
    """Fresh login: drops old cookies (a logged-in session would be
    redirected away from the login page), reads the form's _csrf and
    posts the credentials with "remember me" on."""
    session.cookies.clear()
    try:
        page = session.get(LOGIN_URL, timeout=15).text
    except Exception as e:
        log("login page fetch failed: {0}".format(e))
        return False
    m = re.search(r'<form[^>]*id="login-form".*?</form>', page, re.S)
    fields = parse_inputs(m.group(0)) if m else {}
    if not fields.get('_csrf'):
        log("login: _csrf not found on the login page")
    data = {
        "_csrf": fields.get('_csrf', ''),
        "LoginForm[email]": email,
        "LoginForm[password]": password,
        "LoginForm[rememberMe]": "1",
    }
    try:
        resp = session.post(LOGIN_URL, data=data, headers={"Referer": LOGIN_URL}, timeout=15)
        body = resp.text
    except Exception as e:
        log("login post failed: {0}".format(e))
        return False
    ok = '/site/logout' in body
    log("login {0}".format("OK" if ok else "failed"))
    return ok


class Site(object):
    """Logged-in access to hns.sk: reuses saved cookies and logs in only
    when the site asks for it."""

    def __init__(self, email, password):
        self.email = email
        self.password = password
        self.session = new_session(email)
        self.logged_in_now = False

    def relogin(self):
        if not login(self.session, self.email, self.password):
            raise LoginFailed()
        self.logged_in_now = True
        save_session(self.session, self.email)

    def get(self, url):
        """Page text, logging in first when the site redirects to its
        login page. None on a network error."""
        for attempt in (1, 2):
            try:
                resp = self.session.get(url, timeout=20)
            except Exception as e:
                log("GET {0} failed: {1}".format(url, e))
                return None
            if not is_login_page(resp.text):
                save_session(self.session, self.email)
                return resp.text
            if attempt == 2 or self.logged_in_now:
                raise LoginFailed()
            log("not logged in, logging in")
            self.relogin()
        return None

    def post(self, url, data):
        return self.session.post(url, data=data, headers={"Referer": url}, timeout=20)


def parse_catalog(html_text):
    shows = []
    seen = set()
    for slug, title in re.findall(r'<a\s+href="/anime/([^"/]+)">([^<]+)</a>', html_text):
        if slug in seen:
            continue
        seen.add(slug)
        shows.append({"slug": slug, "title": html_mod.unescape(title).strip()})
    return shows


def get_catalog(site):
    cached = load_json(CATALOG_FILE)
    if cached and (time.time() - cached.get("ts", 0)) < CATALOG_TTL and cached.get("shows"):
        log("using cached catalog ({0} show(s), age {1:.0f}s)".format(
            len(cached["shows"]), time.time() - cached["ts"]))
        return cached["shows"]
    log("catalog cache missing/stale - downloading {0}".format(CATALOG_URL))
    page = site.get(CATALOG_URL)
    shows = parse_catalog(page or '')
    log("catalog: {0} show(s)".format(len(shows)))
    if shows:
        save_json(CATALOG_FILE, {"ts": time.time(), "shows": shows})
    return shows


def parse_releases(row_html):
    """Release rows: release name, translator (<br> uploader), date,
    "version / note" and the download form."""
    cells = re.findall(r'<td[^>]*>(.*?)</td>', row_html, re.S)
    form = re.search(r'<form.*?</form>', row_html, re.S)
    if len(cells) < 5 or not form:
        return None
    fields = parse_inputs(form.group(0))
    if not fields.get('id') or fields.get('download') == 'all':
        return None
    name = fields.get('name') or ''
    if not name:
        m = re.search(r'data-name="([^"]*)"', form.group(0))
        name = html_mod.unescape(m.group(1)) if m else ''
    translator = strip_tags(re.split(r'<br\s*/?>', cells[1])[0])
    version_m = re.match(r'\s*(\d+)', strip_tags(cells[3]))
    return {
        "sub_id": fields['id'],
        "name": name,
        "release": strip_tags(cells[0]),
        "translator": translator,
        "version": version_m.group(1) if version_m else "",
    }


def parse_show_page(html_text):
    """Returns (show title, [release dict with episode info])."""
    title_m = re.search(r'<h3[^>]*\bnazev\b[^>]*>\s*([^<]*)', html_text)
    show_title = html_mod.unescape(title_m.group(1)).strip() if title_m else ''
    releases = []
    for table in re.split(r'<table\b', html_text)[1:]:
        table = table.split('</table>')[0]
        link = re.search(r'<a\s+href="(/anime/episode/[^"]+/(\d+))"\s*>([^<]*)</a>', table)
        if not link:
            continue
        ep_m = re.search(r'(\d+)\s*$', html_mod.unescape(link.group(3)).strip())
        episode = int(ep_m.group(1)) if ep_m else None
        for row in re.findall(r'<tr[^>]*>(.*?)</tr>', table, re.S):
            rel = parse_releases(row)
            if rel:
                rel['episode'] = episode
                rel['episode_url'] = BASE_URL + link.group(1)
                releases.append(rel)
    return show_title, releases


def find_download_form(html_text, sub_id):
    for form in re.findall(r'<form.*?</form>', html_text or '', re.S):
        fields = parse_inputs(form)
        if fields.get('id') == str(sub_id) and fields.get('action') == 'download':
            return fields
    return None


# ---------------- Kodi-facing actions ----------------

def append_subtitle(lang_name, flag_code, label2, url_params):
    listitem = xbmcgui.ListItem(label=lang_name, label2=label2)
    if flag_code:
        listitem.setArt({"thumb": flag_code})
    listitem.setProperty("sync", "false")
    listitem.setProperty("hearing_imp", "false")
    url = "plugin://{0}/?{1}".format(
        ADDON_ID,
        "&".join("{0}={1}".format(k, requests.utils.quote(str(v))) for k, v in url_params.items())
    )
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=listitem, isFolder=False)


def get_credentials():
    email = ADDON.getSetting('email').strip()
    password = ADDON.getSetting('password')
    if not email or not password:
        notify(L('Set your hns.sk e-mail and password in the addon settings.', 'Nastavte svůj e-mail a heslo k hns.sk v nastavení doplňku.'))
        ADDON.openSettings()
        return None, None
    return email, password


def login_failed_notice():
    notify(L('hns.sk login failed - check the e-mail and password in the addon settings.', 'Přihlášení k hns.sk selhalo - zkontrolujte e-mail a heslo v nastavení doplňku.'))


def handle_search(params, is_manual):
    email, password = get_credentials()
    if not email:
        return

    season = episode = None
    if is_manual:
        query, season, episode = parse_video_name(params.get('searchstring', [''])[0])
    else:
        tvshow = xbmc.getInfoLabel("VideoPlayer.TVshowtitle")
        title = tvshow or xbmc.getInfoLabel("VideoPlayer.OriginalTitle") or xbmc.getInfoLabel("VideoPlayer.Title")
        season_label = xbmc.getInfoLabel("VideoPlayer.Season")
        episode_label = xbmc.getInfoLabel("VideoPlayer.Episode")
        if season_label.isdigit():
            season = int(season_label)
        if episode_label.isdigit():
            episode = int(episode_label)

        if title:
            query = clean_release_title(title)
        else:
            try:
                filename = os.path.basename(unquote(xbmc.Player().getPlayingFile()))
            except Exception:
                filename = ""
            query, s2, e2 = parse_video_name(filename)
            if season is None:
                season = s2
            if episode is None:
                episode = e2

    query, title_season = split_season_title((query or "").strip())
    if season is None:
        season = title_season
    if not query:
        log("no usable search query, aborting")
        return

    log("query='{0}' season={1} episode={2} manual={3}".format(query, season, episode, is_manual))

    lang_name, lang_flag = pick_language(get_allowed_languages(params))
    if not lang_name:
        log("neither Czech nor Slovak is in Kodi's requested languages, nothing to show")
        return

    site = Site(email, password)
    try:
        shows = get_catalog(site)
        if not shows:
            return
        candidates = choose_shows(query, season, shows)
        log("show(s) to list: {0}".format([s['title'] for s in candidates]))

        saved = {}
        for show in candidates:
            page = site.get("{0}/anime/{1}".format(BASE_URL, show['slug']))
            if page is None:
                continue
            show_title, releases = parse_show_page(page)
            show_title = show_title or show['title']
            log("'{0}': {1} release(s)".format(show_title, len(releases)))

            if episode is not None:
                matching = [r for r in releases if r['episode'] == episode]
                if matching:
                    releases = matching
                elif len(candidates) > 1:
                    releases = []
                else:
                    log("no release for episode {0}, showing the full list instead".format(episode))

            for rel in releases:
                if len(saved) >= MAX_ITEMS:
                    break
                rid = str(len(saved))
                saved[rid] = {"episode_url": rel['episode_url'], "sub_id": rel['sub_id'],
                              "name": rel['name'], "episode": rel['episode']}
                parts = ["{0} - {1:02d}".format(show_title, rel['episode'] or 0), rel['release']]
                if rel['version'] and rel['version'] != '1':
                    parts.append("v" + rel['version'])
                if rel['translator']:
                    parts.append(rel['translator'])
                label2 = "{0} [CZ/SK]".format(" | ".join(p for p in parts if p))
                append_subtitle(lang_name, lang_flag, label2, {"action": "download", "rid": rid})
            if len(saved) >= MAX_ITEMS:
                log("hit the {0}-item cap, stopping".format(MAX_ITEMS))
                break
    except LoginFailed:
        login_failed_notice()
        return

    save_json(ROWS_FILE, saved)
    log("listed {0} subtitle(s)".format(len(saved)))


def fetch_subtitle(site, row):
    """Episode page -> its download form -> POST. Returns (content,
    error message). Logs in again and retries once when the site answers
    with a page instead of the file (e.g. an expired session)."""
    for attempt in (1, 2):
        page = site.get(row['episode_url'])
        if page is None:
            return None, L('Download failed (see debug log).', 'Stažení selhalo (podrobnosti v logu).')
        fields = find_download_form(page, row['sub_id'])
        if not fields:
            log("no download form for subtitle id {0} on {1}".format(row['sub_id'], row['episode_url']))
            return None, L('This subtitle is no longer on the site - please search again.', 'Tyto titulky už na webu nejsou - vyhledejte prosím znovu.')
        try:
            resp = site.post(row['episode_url'], fields)
            content = resp.content
        except Exception as e:
            log("download post failed: {0}".format(e))
            return None, L('Download failed (see debug log).', 'Stažení selhalo (podrobnosti v logu).')
        sample = content[:300].lstrip(b'\xef\xbb\xbf \t\r\n')
        if content and not sample.startswith(b'<'):
            return content, None
        log("download returned a page (status {0}, attempt {1}): {2}".format(
            resp.status_code, attempt, sample[:80]))
        if attempt == 1 and not site.logged_in_now:
            site.relogin()
    return None, L('Download failed - the site returned a page instead of a subtitle (see debug log).', 'Stažení selhalo - web místo titulků vrátil stránku (podrobnosti v logu).')


def safe_file_name(name):
    name = re.sub(r'[\\/:*?"<>|\x00-\x1f]+', ' ', name or '')
    name = re.sub(r'\s+', ' ', name).strip(' .')
    return name[:120]


def save_subtitle(content, row):
    stamp = int(time.time())
    if content[:2] == b'PK':
        extract_dir = os.path.join(TEMP_DIR, "hns_{0}_{1}".format(row['sub_id'], stamp))
        zip_path = extract_dir + ".zip"
        try:
            with open(zip_path, 'wb') as f:
                f.write(content)
            with zipfile.ZipFile(zip_path) as zf:
                if sum(info.file_size for info in zf.infolist()) > MAX_EXTRACTED_BYTES:
                    log("refusing to extract {0}: too large".format(zip_path))
                    return None
                zf.extractall(extract_dir)
        except Exception as e:
            log("zip handling failed: {0}".format(e))
            return None
        for root, _dirs, files in os.walk(extract_dir):
            for fn in sorted(files):
                if fn.lower().endswith(SUB_EXTENSIONS):
                    return os.path.join(root, fn)
        log("no subtitle file inside {0}".format(zip_path))
        return None

    base = safe_file_name(row.get('name')) or "episode {0}".format(row.get('episode'))
    stem, ext = os.path.splitext(base)
    if ext.lower() not in SUB_EXTENSIONS:
        stem = base
        text_start = content[:300].lstrip(b'\xef\xbb\xbf \t\r\n')
        ext = '.ass' if text_start.startswith(b'[Script Info]') else '.srt'
    folder = os.path.join(TEMP_DIR, "hns_{0}_{1}".format(row['sub_id'], stamp))
    path = os.path.join(folder, stem + ext)
    try:
        os.makedirs(folder, exist_ok=True)
        with open(path, 'wb') as f:
            f.write(content)
    except Exception as e:
        log("failed to write subtitle file: {0}".format(e))
        return None
    return path


def handle_download(params):
    rid = params.get('rid', [None])[0]
    if rid is None:
        notify(L('Nothing to download.', 'Není co stáhnout.'))
        return
    row = (load_json(ROWS_FILE) or {}).get(rid)
    if not row:
        notify(L('Subtitle info expired - please search again.', 'Údaje o titulcích vypršely - vyhledejte prosím znovu.'))
        return
    email, password = get_credentials()
    if not email:
        return

    site = Site(email, password)
    try:
        content, error = fetch_subtitle(site, row)
    except LoginFailed:
        login_failed_notice()
        return
    if error:
        notify(error)
        return

    if len(content) > MAX_DOWNLOAD_BYTES:
        notify(L('Download refused - file is larger than expected (see debug log).', 'Stažení odmítnuto - soubor je větší, než by měl být (podrobnosti v logu).'))
        log("download refused: {0} bytes exceeds MAX_DOWNLOAD_BYTES {1}".format(
            len(content), MAX_DOWNLOAD_BYTES))
        return

    filepath = save_subtitle(content, row)
    if not filepath:
        notify(L("Downloaded but couldn't save the subtitle (see debug log).", 'Staženo, ale titulky se nepodařilo uložit (podrobnosti v logu).'))
        return

    remember_owner(filepath)
    log("saved subtitle to {0}".format(filepath))
    listitem = xbmcgui.ListItem(label=os.path.basename(filepath))
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=filepath, listitem=listitem, isFolder=False)


def run():
    try:
        cleanup_temp_dir()
        params = get_params()
        action = params.get('action', [''])[0]
        log("action={0} params={1}".format(action, params))
        if action == 'search':
            handle_search(params, is_manual=False)
        elif action == 'manualsearch':
            handle_search(params, is_manual=True)
        elif action == 'download':
            handle_download(params)
        else:
            log("unknown/missing action, nothing to do")
    except Exception as e:
        log("unhandled exception: {0}\n{1}".format(e, traceback.format_exc()))
    finally:
        xbmcplugin.endOfDirectory(HANDLE)


if __name__ == '__main__':
    run()
