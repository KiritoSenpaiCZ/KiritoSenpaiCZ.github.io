# -*- coding: utf-8 -*-
"""
Hiyori.cz Subtitle Downloader - Kodi subtitle service addon.

Reuses the site-scraping logic proven live in the hiyori.lua VLC
extension (this addon's Python port of that same logic).

Design choices carried over on purpose:
- No session/login caching - logs in fresh on every search and every
  download. Simplicity over performance.
- Subtitle table parsing is content-based, not column-index-based
  (language cell = exact "CZ"/"SK" text; episode number + episode
  title = the td pair where a short bare-digit td is immediately
  followed by a title td; download link = whichever <a> in the row
  has "btn-primary" in its class or an onclick starting with
  "Download") - this avoids the single biggest recurring bug class
  on this site (column order isn't stable across anime pages).
- External/forwarded subtitles are listed but never auto-downloaded -
  selecting one shows the raw URL instead. Their label shows the actual
  fansub group's name (e.g. "[Kamui-Subs]"), not a generic "[EXTERNAL]",
  so Jan can tell which of his other addons/sites actually has the file.
- Heavy debug logging via log() - enable Kodi's debug log
  (Settings -> System -> Logging), reproduce, then grep kodi.log for
  "[Hiyori]" and paste the lines back for troubleshooting.
"""

import difflib
import html as html_mod
import json
import os
import re
import shutil
import sys
import time
import traceback
from urllib.parse import parse_qs, unquote, urlparse

import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')

PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
TEMP_DIR = xbmcvfs.translatePath(os.path.join(PROFILE, 'temp', ''))
if not xbmcvfs.exists(TEMP_DIR):
    xbmcvfs.mkdirs(TEMP_DIR)
ROWS_FILE = os.path.join(TEMP_DIR, 'hiyori_rows.json')
OWNERS_FILE = os.path.join(TEMP_DIR, 'hiyori_owners.json')

HANDLE = int(sys.argv[1])

BASE_URL = "https://hiyori.cz"
HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                  "(KHTML, like Gecko) Chrome/124.0 Safari/537.36"
}

LANG_NAMES = {"CZ": "Czech", "SK": "Slovak"}
LANG_FLAGS = {"CZ": "cs", "SK": "sk"}  # ISO 639-1 codes Kodi's flag art expects

# Anything left behind in TEMP_DIR older than this gets swept on the next
# run - a search+download round trip finishes in well under a minute, so
# anything still there an hour later is leftover, not in-use.
TEMP_MAX_AGE_SECONDS = 3600

# Refuse an implausibly large download - subtitle files are small, so
# hitting this means something's wrong (a huge unexpected response).
MAX_DOWNLOAD_BYTES = 20 * 1024 * 1024

# External/forwarded subtitles point at the fansub group's own site rather
# than a generic "[EXTERNAL]" label, so Jan can tell at a glance which of
# his other addons/sites actually has the file (e.g. a Slime S4 row
# forwarded to kamui-subs.cz shows "[Kamui-Subs]", not just "[EXTERNAL]").
# Keyed by domain (without "www."); anything not in this map falls back to
# a title-cased guess from the domain itself rather than a bare "External".
EXTERNAL_SITE_NAMES = {
    "kamui-subs.cz": "Kamui-Subs",
    "wosir.cz": "WoSir",
    "edna.cz": "Edna",
    "titulky.com": "Titulky",
    "premium.titulky.com": "Titulky",
}


def external_source_name(href):
    try:
        host = (urlparse(href).netloc or "").lower()
    except Exception:
        return "External"
    if host.startswith("www."):
        host = host[4:]
    if host in EXTERNAL_SITE_NAMES:
        return EXTERNAL_SITE_NAMES[host]
    base = host.split(".")[0] if host else ""
    return base.capitalize() if base else "External"

# ---------------- small helpers ----------------

def log(msg):
    xbmc.log("[Hiyori] {0}".format(msg), level=xbmc.LOGDEBUG)

def notify(msg):
    xbmcgui.Dialog().notification(ADDON_NAME, msg, xbmcgui.NOTIFICATION_INFO, 4000)

def get_params():
    raw = sys.argv[2] if len(sys.argv) > 2 else ""
    return parse_qs(raw.lstrip('?'))

def save_rows(rows_dict):
    try:
        with open(ROWS_FILE, 'w', encoding='utf-8') as f:
            json.dump(rows_dict, f)
    except Exception as e:
        log("failed to save rows cache: {0}".format(e))

def load_rows():
    try:
        with open(ROWS_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {}

def current_video():
    """Path of the video Kodi has loaded - playing OR paused - else None.
    (Player.Playing alone isn't enough: it's false while paused.)"""
    try:
        if xbmc.getCondVisibility('Player.HasVideo') or xbmc.getCondVisibility('Player.Paused'):
            return xbmc.getInfoLabel('Player.Filenameandpath') or None
    except Exception:
        pass
    return None


def _read_owners():
    try:
        with open(OWNERS_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _write_owners(owners):
    try:
        with open(OWNERS_FILE, 'w', encoding='utf-8') as f:
            json.dump(owners, f)
    except Exception as e:
        log("couldn't save {0}: {1}".format(OWNERS_FILE, e))


def remember_owner(path):
    """Record which video a delivered subtitle belongs to, so
    cleanup_temp_dir() never deletes it while that video is still loaded
    (e.g. paused for more than an hour) - suggested by Hanabi's API
    maintainer."""
    video = current_video()
    if not video:
        return
    try:
        top = os.path.relpath(path, TEMP_DIR).split(os.sep)[0]
    except ValueError:
        return
    if not top or top.startswith('..'):
        return
    owners = _read_owners()
    owners[top] = video
    _write_owners(owners)


def cleanup_temp_dir():
    """Sweep old downloads out of TEMP_DIR (they used to accumulate
    forever). Kept: the small caches managed by their own logic, and every
    subtitle belonging to the video Kodi currently has loaded - playing or
    paused - however old it is, so a long pause can't delete a subtitle
    that's still in use."""
    keep = {os.path.basename(ROWS_FILE), os.path.basename(OWNERS_FILE)}
    owners = _read_owners()
    video = current_video()
    try:
        now = time.time()
        for name in os.listdir(TEMP_DIR):
            if name in keep or not name.startswith('hiyori_'):
                continue
            if video and owners.get(name) == video:
                continue
            path = os.path.join(TEMP_DIR, name)
            try:
                age = now - os.path.getmtime(path)
            except OSError:
                continue
            if age < TEMP_MAX_AGE_SECONDS:
                continue
            try:
                if os.path.isdir(path):
                    shutil.rmtree(path, ignore_errors=True)
                else:
                    os.remove(path)
            except OSError as e:
                log("cleanup: couldn't remove {0}: {1}".format(path, e))
        existing = set(os.listdir(TEMP_DIR))
        still_there = dict((k, v) for k, v in owners.items() if k in existing)
        if still_there != owners:
            _write_owners(still_there)
    except Exception as e:
        log("cleanup_temp_dir failed: {0}".format(e))

# ---------------- title/query cleanup ----------------

def clean_release_title(name):
    """Strip season/episode markers and release-scene tags from a raw
    filename/title, so a search query like '... S02E01 1080p BluRay
    Dual-Audio Opus 2 0 x265-GROUP' doesn't get zero search hits."""
    if not name:
        return name
    name = re.sub(r'\.\w+$', '', name)  # extension
    name = re.sub(r'\[[^\]]*\]', ' ', name)  # [tags]
    name = re.sub(r'\([^)]*\)', ' ', name)  # (tags)
    name = re.sub(r'[._]', ' ', name)  # dots/underscores -> spaces

    lower = name.lower()
    cut_at = None
    m = re.search(r's\d{1,2}e\d{1,2}', lower)
    if m:
        cut_at = m.start()
    keywords = [
        "2160p", "1080p", "720p", "480p", "4k",
        "blu-ray", "bluray", "bdrip", "webrip", "web-dl", "web dl",
        "hdtv", "dvdrip", "hdrip",
        "x264", "x265", "h264", "h265", "hevc", "avc",
        "dual audio", "dual-audio", "multi audio", "multi-audio",
        "aac", "flac", "dts", "opus",
    ]
    for kw in keywords:
        idx = lower.find(kw)
        if idx != -1 and (cut_at is None or idx < cut_at):
            cut_at = idx
    if cut_at is not None:
        name = name[:cut_at]

    name = re.sub(r'\s-\s*\d+.*$', '', name)  # trailing "- 05..." marker
    name = re.sub(r'[-–—]+\s*$', '', name)  # leftover trailing dash
    name = re.sub(r'\s+', ' ', name).strip()
    return name

def extract_season_episode(text):
    """Pull a leading/embedded 'S01E02' style marker out of a string
    (mainly for Kodi's manual-search box), returning (cleaned_text,
    season, episode)."""
    if not text:
        return text, None, None
    m = re.search(r'[sS](\d{1,2})[eE](\d{1,3})', text)
    if not m:
        return text, None, None
    season = int(m.group(1))
    episode = int(m.group(2))
    cleaned = (text[:m.start()] + text[m.end():]).strip()
    cleaned = clean_release_title(cleaned) or cleaned
    return cleaned, season, episode

def pick_best_match(query, shows):
    """Case-insensitive closest-title match."""
    if not shows:
        return None
    titles_lower = [s['title'].lower() for s in shows]
    close = difflib.get_close_matches(query.lower(), titles_lower, n=1, cutoff=0.0)
    if close:
        return shows[titles_lower.index(close[0])]
    return shows[0]

def get_allowed_languages(params):
    raw = params.get('languages', [''])[0]
    if not raw:
        return None
    return set(unquote(n) for n in raw.split(','))

# ---------------- site access ----------------

def login(session, username, password):
    try:
        resp = session.post(
            "{0}/account/login".format(BASE_URL),
            data={"username": username, "Password": password, "remember_me": "1"},
            headers=HEADERS, timeout=15
        )
        return resp.status_code < 400
    except Exception as e:
        log("login request failed: {0}".format(e))
        return False

def search_site(session, query):
    try:
        resp = session.get(
            "{0}/rozcestnik".format(BASE_URL),
            params={"nazev": query}, headers=HEADERS, timeout=15
        )
        html_text = resp.text
    except Exception as e:
        log("search request failed: {0}".format(e))
        return []
    results = []
    for m in re.finditer(r'href="/anime/(\d+)"\s+title="([^"]+)"', html_text):
        results.append({"id": m.group(1), "title": html_mod.unescape(m.group(2))})
    return results

def find_download_link(row_html):
    """Scans every <a> tag in a row and returns the href of whichever one
    is the real download button - identified by class containing
    'btn-primary' or an onclick starting with 'Download', not by exact
    attribute-string match (attribute order/extra classes vary by page)."""
    for attrs in re.findall(r'<a\s+([^>]*?)>', row_html):
        cls_m = re.search(r'class="([^"]*)"', attrs)
        href_m = re.search(r'href="([^"]*)"', attrs)
        onclick_m = re.search(r'onclick="([^"]*)"', attrs)
        cls = cls_m.group(1) if cls_m else ""
        href = href_m.group(1) if href_m else None
        onclick = onclick_m.group(1) if onclick_m else ""
        if href and ("btn-primary" in cls or onclick.startswith("Download")):
            return href
    return None

def parse_subtitle_rows(html_text):
    """Content-based parsing (not fixed column index - column order can
    vary across anime pages)."""
    rows = []
    row_count = 0
    skipped = 0
    for row_html in re.findall(r'<tr.*?</tr>', html_text, re.DOTALL):
        row_count += 1
        lang_m = re.search(r'<td[^>]*>\s*(CZ|SK)\s*</td>', row_html)
        lang = lang_m.group(1) if lang_m else None

        # episode number + episode title: the title td always sits directly
        # after the short bare-digit episode-number td
        ep_title_m = re.search(
            r'<td[^>]*>\s*(\d{1,3})\s*</td>\s*<td[^>]*>\s*(.*?)\s*</td>',
            row_html, re.DOTALL
        )
        ep = ep_title_m.group(1) if ep_title_m else "?"
        title = "?"
        if ep_title_m:
            title = html_mod.unescape(re.sub(r'<[^>]+>', '', ep_title_m.group(2))).strip() or "?"

        href = find_download_link(row_html)

        if not lang or not href:
            skipped += 1
            log("skipped row {0} (lang={1} href={2})".format(row_count, lang, href))
            continue

        internal = href.startswith("/anime/downloadsubtitles")
        rows.append({
            "ep": ep,
            "lang": lang,
            "title": title,
            "href": (BASE_URL + href) if internal else href,
            "internal": internal,
        })
        log("row {0} OK: ep={1} lang={2} title={3} internal={4}".format(
            row_count, ep, lang, title, internal))

    log("parsed {0} <tr> rows, {1} usable, {2} skipped".format(row_count, len(rows), skipped))
    return rows

def guess_extension(content_disposition, body_sample):
    m = re.search(r'filename\*?=[^\'"]*[\'"]?([^\'";\r\n]+)', content_disposition or "")
    if m:
        ext_m = re.search(r'\.([A-Za-z]+)$', m.group(1))
        if ext_m:
            return "." + ext_m.group(1)
    try:
        sample_text = body_sample.decode('utf-8', 'ignore')
    except Exception:
        sample_text = ""
    if sample_text.strip().startswith("[Script Info]"):
        return ".ass"
    return ".srt"

# ---------------- Kodi-facing actions ----------------

def append_subtitle(lang_name, flag_code, label2, url_params):
    listitem = xbmcgui.ListItem(label=lang_name, label2=label2)
    if flag_code:
        listitem.setArt({"thumb": flag_code})
    listitem.setProperty("sync", "false")
    listitem.setProperty("hearing_imp", "false")
    url = "plugin://{0}/?{1}".format(
        ADDON_ID,
        "&".join("{0}={1}".format(k, requests.utils.quote(str(v))) for k, v in url_params.items())
    )
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=listitem, isFolder=False)

def handle_search(params, is_manual):
    username = ADDON.getSetting('username')
    password = ADDON.getSetting('password')
    if not username or not password:
        notify("Set your hiyori.cz username/password in the addon settings.")
        ADDON.openSettings()
        return

    season = episode = None
    if is_manual:
        query_raw = params.get('searchstring', [''])[0]
        query, season, episode = extract_season_episode(query_raw)
        if not query:
            query = clean_release_title(query_raw)
    else:
        tvshow = xbmc.getInfoLabel("VideoPlayer.TVshowtitle")
        title = tvshow or xbmc.getInfoLabel("VideoPlayer.OriginalTitle") or xbmc.getInfoLabel("VideoPlayer.Title")
        season_label = xbmc.getInfoLabel("VideoPlayer.Season")
        episode_label = xbmc.getInfoLabel("VideoPlayer.Episode")
        if season_label.isdigit():
            season = int(season_label)
        if episode_label.isdigit():
            episode = int(episode_label)

        if title:
            query = clean_release_title(title)
        else:
            # fallback for unscraped local files: clean up the raw filename
            try:
                filename = os.path.basename(unquote(xbmc.Player().getPlayingFile()))
            except Exception:
                filename = ""
            query, s2, e2 = extract_season_episode(filename)
            query = clean_release_title(query)
            if season is None:
                season = s2
            if episode is None:
                episode = e2

    query = (query or "").strip()
    if not query:
        log("no usable search query, aborting")
        return

    log("query='{0}' season={1} episode={2} manual={3}".format(query, season, episode, is_manual))

    session = requests.Session()
    if not login(session, username, password):
        notify("Hiyori.cz login failed - check username/password in addon settings.")
        return

    shows = search_site(session, query)
    log("{0} show match(es) for '{1}'".format(len(shows), query))
    if not shows:
        return

    best = pick_best_match(query, shows)
    log("picked show: '{0}' (id={1})".format(best['title'], best['id']))

    try:
        resp = session.get("{0}/anime/{1}".format(BASE_URL, best['id']), headers=HEADERS, timeout=15)
        html_text = resp.text
    except Exception as e:
        log("subtitle table fetch failed: {0}".format(e))
        return

    rows = parse_subtitle_rows(html_text)

    if episode is not None:
        matching = [r for r in rows if r['ep'] == str(episode)]
        if matching:
            rows = matching
        else:
            log("no rows matched episode {0}, showing full list instead".format(episode))

    allowed_langs = get_allowed_languages(params)
    saved = {}
    shown = 0
    for i, row in enumerate(rows):
        lang_name = LANG_NAMES.get(row['lang'], row['lang'])
        if allowed_langs and lang_name not in allowed_langs:
            continue
        rid = str(i)
        saved[rid] = row
        prefix = "" if row['internal'] else "[{0}] ".format(external_source_name(row['href']))
        label2 = "{0}Ep {1} - {2}".format(prefix, row['ep'], row['title'])
        append_subtitle(lang_name, LANG_FLAGS.get(row['lang'], ''), label2, {"action": "download", "rid": rid})
        shown += 1

    save_rows(saved)
    log("listed {0} subtitle(s) for '{1}'".format(shown, best['title']))

def handle_download(params):
    rid = params.get('rid', [None])[0]
    if rid is None:
        notify("Nothing to download.")
        return
    rows = load_rows()
    row = rows.get(rid)
    if not row:
        notify("Subtitle info expired - please search again.")
        return

    if not row.get('internal', True):
        # external/forwarded subtitle - never auto-downloaded (it's hosted
        # on another fansub site with its own separate login)
        source = external_source_name(row['href'])
        xbmcgui.Dialog().textviewer("External subtitle link - {0}".format(source), row['href'])
        log("external subtitle link shown ({0}): {1}".format(source, row['href']))
        return

    username = ADDON.getSetting('username')
    password = ADDON.getSetting('password')
    session = requests.Session()
    if not login(session, username, password):
        notify("Login failed - check username/password in addon settings.")
        return

    try:
        resp = session.get(row['href'], headers=HEADERS, timeout=20)
        content = resp.content
        content_disposition = resp.headers.get('Content-Disposition', '')
    except Exception as e:
        log("download failed: {0}".format(e))
        notify("Download failed (see debug log).")
        return

    if not content or content.lstrip()[:1] == b'<':
        notify("Download failed - unexpected response (see debug log). Try again in a moment.")
        log("download got empty/HTML body for ep {0} [{1}]".format(row.get('ep'), row.get('lang')))
        return

    if len(content) > MAX_DOWNLOAD_BYTES:
        notify("Download refused - file is larger than expected (see debug log).")
        log("download refused: {0} bytes exceeds MAX_DOWNLOAD_BYTES {1}".format(
            len(content), MAX_DOWNLOAD_BYTES))
        return

    ext = guess_extension(content_disposition, content[:200])
    filename = "hiyori_ep{0}_{1}_{2}{3}".format(row['ep'], row['lang'], int(time.time()), ext)
    filepath = os.path.join(TEMP_DIR, filename)
    try:
        with open(filepath, 'wb') as f:
            f.write(content)
    except Exception as e:
        log("failed to write subtitle file: {0}".format(e))
        notify("Downloaded but couldn't save the file (see debug log).")
        return

    remember_owner(filepath)

    log("saved subtitle to {0}".format(filepath))
    listitem = xbmcgui.ListItem(label=filename)
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=filepath, listitem=listitem, isFolder=False)

def run():
    try:
        cleanup_temp_dir()
        params = get_params()
        action = params.get('action', [''])[0]
        log("action={0} params={1}".format(action, params))
        if action == 'search':
            handle_search(params, is_manual=False)
        elif action == 'manualsearch':
            handle_search(params, is_manual=True)
        elif action == 'download':
            handle_download(params)
        else:
            log("unknown/missing action, nothing to do")
    except Exception as e:
        log("unhandled exception: {0}\n{1}".format(e, traceback.format_exc()))
    finally:
        xbmcplugin.endOfDirectory(HANDLE)

if __name__ == '__main__':
    run()
