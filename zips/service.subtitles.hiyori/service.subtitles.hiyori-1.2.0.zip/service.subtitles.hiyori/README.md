# Hiyori Subtitles - Kodi Subtitle Addon

Kodi subtitle service addon for hiyori.cz — Czech/Slovak anime subtitles.

Compatible with Kodi 19, 20, and 21.

## Current Version
service.subtitles.hiyori - 1.2.0

## Installation Instructions
Recommended: install through the [Highflight Subtitles Repository](https://github.com/KiritoSenpaiCZ/KiritoSenpaiCZ.github.io), which also handles updates.

Manual install:
1. Download `service.subtitles.hiyori-1.2.0.zip` from this repo (or build it from source)
2. In Kodi: **Add-ons > Install from zip file**, select the zip

## Setup Instructions
1. In Kodi, open this addon's settings
2. Enter your hiyori.cz username and password

## How it works
- Messages and settings are in Czech when Kodi is set to Czech or Slovak, and in English otherwise
- Searches hiyori.cz using the show title from Kodi's video metadata (or a manual search)
- Lists available subtitles, including ones hosted on other fansub sites (shown as a link, not auto-downloaded)
- Logs in fresh on every search/download — no session is cached
- Downloaded files are validated before use (rejects HTML error pages and oversized responses) and old temp files are swept automatically

## Issues
Please open an issue in this repo with a description of the problem and, if possible, a Kodi debug log (Settings > System > Logging > Enable debug logging, then grep `kodi.log` for `[Hiyori]`).
