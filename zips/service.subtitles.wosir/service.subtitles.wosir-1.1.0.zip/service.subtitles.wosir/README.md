# WoSir Subtitles - Kodi Subtitle Addon

Kodi subtitle service addon for wosir.cz — Czech anime subtitles.

Compatible with Kodi 19, 20, and 21.

## Current Version
service.subtitles.wosir - 1.1.0

## Installation Instructions
Recommended: install through the [Highflight Subtitles Repository](https://github.com/KiritoSenpaiCZ/KiritoSenpaiCZ.github.io), which also handles updates.

Manual install:
1. Download `service.subtitles.wosir-1.1.0.zip` from this repo (or build it from source)
2. In Kodi: **Add-ons > Install from zip file**, select the zip

## Setup Instructions
1. In Kodi, open this addon's settings
2. Enter your wosir.cz username and password

## How it works
- Searches wosir.cz using the show title from Kodi's video metadata (or a manual search)
- Lists available subtitles, including both TV and Blu-ray releases where available
- Logs in fresh on every search/download — no session is cached
- Downloaded files are validated before use (rejects HTML error pages and oversized responses) and old temp files are swept automatically

## Issues
Please open an issue in this repo with a description of the problem and, if possible, a Kodi debug log (Settings > System > Logging > Enable debug logging, then grep `kodi.log` for `[WoSir]`).
