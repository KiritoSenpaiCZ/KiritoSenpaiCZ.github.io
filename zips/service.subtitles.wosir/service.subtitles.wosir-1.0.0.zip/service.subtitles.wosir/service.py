# -*- coding: utf-8 -*-
"""
WoSir.cz Subtitle Downloader - Kodi subtitle service addon.

Reuses the site-scraping logic proven live in the wosir.lua VLC
extension (this addon's Python port of that same logic).

WoSir specifics vs. Hiyori (see service.subtitles.hiyori for that one):
- Login needs a CSRF token scraped from the login page first, and a
  fresh cookie jar every time (a still-"logged in" cookie makes the
  login page redirect away before a token can be scraped) - achieved
  here simply by using a brand new requests.Session() per login.
- Everything on this site is Czech - no language column to parse.
- Each row can be a TV or a Blu-ray (BD) release, told apart by which
  hidden form field is present (file_to_download vs
  file_to_download_BD). The real "Stahnout" download button is that
  form's POST - not the separate "Zkopirovat URL" button, which is a
  different, decoy/convenience code path.
- No external/forwarded-subtitle concept here, unlike Hiyori.

Design choices carried over on purpose (see service.subtitles.hiyori for
the shared rationale): no session caching, content-based table parsing,
heavy debug logging via log() - grep kodi.log for "[WoSir]".
"""

import difflib
import html as html_mod
import json
import os
import re
import sys
import time
import traceback
from urllib.parse import parse_qs, unquote

import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')

PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
TEMP_DIR = xbmcvfs.translatePath(os.path.join(PROFILE, 'temp', ''))
if not xbmcvfs.exists(TEMP_DIR):
    xbmcvfs.mkdirs(TEMP_DIR)
ROWS_FILE = os.path.join(TEMP_DIR, 'wosir_rows.json')

HANDLE = int(sys.argv[1])

BASE_URL = "https://www.wosir.cz"
HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                  "(KHTML, like Gecko) Chrome/124.0 Safari/537.36"
}

LANG_NAME = "Czech"
LANG_FLAG = "cs"  # ISO 639-1 code Kodi's flag art expects

# ---------------- small helpers ----------------

def log(msg):
    xbmc.log("[WoSir] {0}".format(msg), level=xbmc.LOGDEBUG)

def notify(msg):
    xbmcgui.Dialog().notification(ADDON_NAME, msg, xbmcgui.NOTIFICATION_INFO, 4000)

def get_params():
    raw = sys.argv[2] if len(sys.argv) > 2 else ""
    return parse_qs(raw.lstrip('?'))

def save_rows(rows_dict):
    try:
        with open(ROWS_FILE, 'w', encoding='utf-8') as f:
            json.dump(rows_dict, f)
    except Exception as e:
        log("failed to save rows cache: {0}".format(e))

def load_rows():
    try:
        with open(ROWS_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {}

# ---------------- title/query cleanup (identical logic to Hiyori) ----------------

def clean_release_title(name):
    if not name:
        return name
    name = re.sub(r'\.\w+$', '', name)
    name = re.sub(r'\[[^\]]*\]', ' ', name)
    name = re.sub(r'\([^)]*\)', ' ', name)
    name = re.sub(r'[._]', ' ', name)

    lower = name.lower()
    cut_at = None
    m = re.search(r's\d{1,2}e\d{1,2}', lower)
    if m:
        cut_at = m.start()
    keywords = [
        "2160p", "1080p", "720p", "480p", "4k",
        "blu-ray", "bluray", "bdrip", "webrip", "web-dl", "web dl",
        "hdtv", "dvdrip", "hdrip",
        "x264", "x265", "h264", "h265", "hevc", "avc",
        "dual audio", "dual-audio", "multi audio", "multi-audio",
        "aac", "flac", "dts", "opus",
    ]
    for kw in keywords:
        idx = lower.find(kw)
        if idx != -1 and (cut_at is None or idx < cut_at):
            cut_at = idx
    if cut_at is not None:
        name = name[:cut_at]

    name = re.sub(r'\s-\s*\d+.*$', '', name)
    name = re.sub(r'[-–—]+\s*$', '', name)
    name = re.sub(r'\s+', ' ', name).strip()
    return name

def extract_season_episode(text):
    if not text:
        return text, None, None
    m = re.search(r'[sS](\d{1,2})[eE](\d{1,3})', text)
    if not m:
        return text, None, None
    season = int(m.group(1))
    episode = int(m.group(2))
    cleaned = (text[:m.start()] + text[m.end():]).strip()
    cleaned = clean_release_title(cleaned) or cleaned
    return cleaned, season, episode

def pick_best_match(query, shows):
    if not shows:
        return None
    titles_lower = [s['title'].lower() for s in shows]
    close = difflib.get_close_matches(query.lower(), titles_lower, n=1, cutoff=0.0)
    if close:
        return shows[titles_lower.index(close[0])]
    return shows[0]

def get_allowed_languages(params):
    raw = params.get('languages', [''])[0]
    if not raw:
        return None
    return set(unquote(n) for n in raw.split(','))

# ---------------- site access ----------------

def extract_attr(attrs, name):
    m = re.search(r'{0}="([^"]*)"'.format(name), attrs)
    return m.group(1) if m else None

def anime_url(anime_id):
    return "{0}/anime.php?id={1}".format(BASE_URL, anime_id)

def login(session, username, password):
    """Fresh login. Session must be a brand-new requests.Session() (no
    leftover cookies), otherwise the CSRF-protected login page can
    redirect away as "already logged in" before a token is scraped."""
    try:
        resp = session.get("{0}/prihlaseni".format(BASE_URL), headers=HEADERS, timeout=15)
        page = resp.text
    except Exception as e:
        log("login page fetch failed: {0}".format(e))
        return False

    csrf = None
    for attrs in re.findall(r'<input\s+([^>]*?)/?>', page):
        if extract_attr(attrs, "name") == "csrf_token":
            csrf = extract_attr(attrs, "value")
            break
    if not csrf:
        log("login: csrf_token not found on login page")

    data = {
        "prezdivka": username,
        "heslo": password,
        "csrf_token": csrf or "",
        "sub": "Přihlásit",
    }
    try:
        resp = session.post(
            "{0}/prihlaseni".format(BASE_URL), data=data,
            headers={**HEADERS, "Referer": "{0}/prihlaseni".format(BASE_URL)},
            timeout=15
        )
        body = resp.text
    except Exception as e:
        log("login post failed: {0}".format(e))
        return False

    return ("odhlásit" in body) or ("logout.php" in body)

def search_site(session, query):
    try:
        resp = session.get(
            "{0}/preklady".format(BASE_URL),
            params={"search": query, "search_sub": "Hledat"},
            headers=HEADERS, timeout=15
        )
        html_text = resp.text
    except Exception as e:
        log("search request failed: {0}".format(e))
        return []
    results = []
    for m in re.finditer(
        r'<a[^>]*?href="[^"]*?anime\?id=(\d+)"[^>]*>.*?<span[^>]*>([^<]+)</span>',
        html_text, re.DOTALL
    ):
        results.append({"id": m.group(1), "title": html_mod.unescape(m.group(2))})
    return results

def parse_inputs(form_html):
    fields = {}
    for attrs in re.findall(r'<input\s+([^>]*?)/?>', form_html):
        name = extract_attr(attrs, "name")
        if name:
            fields[name] = extract_attr(attrs, "value") or ""
    return fields

def parse_subtitle_rows(html_text):
    """Content-based parsing: episode number + title from the td-pair
    adjacency (same lesson as Hiyori), TV/BD told apart by which hidden
    field is present in the row's real download form (not the visible
    'Blu-ray' text label, which can say other things)."""
    rows = []
    row_count = 0
    skipped = 0
    for row_html in re.findall(r'<tr[^>]*class="[^"]*tsubs[^"]*"[^>]*>.*?</tr>', html_text, re.DOTALL):
        row_count += 1

        ep_title_m = re.search(
            r'<td[^>]*>\s*(\d{1,3})\s*</td>\s*<td[^>]*>\s*(.*?)\s*</td>',
            row_html, re.DOTALL
        )
        ep = ep_title_m.group(1) if ep_title_m else None
        title = "?"
        if ep_title_m:
            title = html_mod.unescape(re.sub(r'<[^>]+>', '', ep_title_m.group(2))).strip() or "?"

        fields = None
        is_bd = False
        for form_html in re.findall(r'<form.*?</form>', row_html, re.DOTALL):
            f = parse_inputs(form_html)
            if 'file_to_download_BD' in f:
                fields, is_bd = f, True
                break
            elif 'file_to_download' in f:
                fields, is_bd = f, False
                break

        if not ep or not fields:
            skipped += 1
            log("skipped row {0} (ep={1} has_fields={2})".format(row_count, ep, fields is not None))
            continue

        rows.append({"ep": ep, "title": title, "is_bd": is_bd, "fields": fields})
        log("row {0} OK: ep={1} bd={2} title={3}".format(row_count, ep, is_bd, title))

    log("parsed {0} <tr class=tsubs> rows, {1} usable, {2} skipped".format(row_count, len(rows), skipped))
    return rows

# ---------------- Kodi-facing actions ----------------

def append_subtitle(label2, url_params):
    listitem = xbmcgui.ListItem(label=LANG_NAME, label2=label2)
    listitem.setArt({"thumb": LANG_FLAG})
    listitem.setProperty("sync", "false")
    listitem.setProperty("hearing_imp", "false")
    url = "plugin://{0}/?{1}".format(
        ADDON_ID,
        "&".join("{0}={1}".format(k, requests.utils.quote(str(v))) for k, v in url_params.items())
    )
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=listitem, isFolder=False)

def handle_search(params, is_manual):
    username = ADDON.getSetting('username')
    password = ADDON.getSetting('password')
    if not username or not password:
        notify("Set your wosir.cz username/password in the addon settings.")
        ADDON.openSettings()
        return

    season = episode = None
    if is_manual:
        query_raw = params.get('searchstring', [''])[0]
        query, season, episode = extract_season_episode(query_raw)
        if not query:
            query = clean_release_title(query_raw)
    else:
        tvshow = xbmc.getInfoLabel("VideoPlayer.TVshowtitle")
        title = tvshow or xbmc.getInfoLabel("VideoPlayer.OriginalTitle") or xbmc.getInfoLabel("VideoPlayer.Title")
        season_label = xbmc.getInfoLabel("VideoPlayer.Season")
        episode_label = xbmc.getInfoLabel("VideoPlayer.Episode")
        if season_label.isdigit():
            season = int(season_label)
        if episode_label.isdigit():
            episode = int(episode_label)

        if title:
            query = clean_release_title(title)
        else:
            try:
                filename = os.path.basename(unquote(xbmc.Player().getPlayingFile()))
            except Exception:
                filename = ""
            query, s2, e2 = extract_season_episode(filename)
            query = clean_release_title(query)
            if season is None:
                season = s2
            if episode is None:
                episode = e2

    query = (query or "").strip()
    if not query:
        log("no usable search query, aborting")
        return

    log("query='{0}' season={1} episode={2} manual={3}".format(query, season, episode, is_manual))

    allowed_langs = get_allowed_languages(params)
    if allowed_langs and LANG_NAME not in allowed_langs:
        log("Czech not in requested languages {0}, nothing to offer".format(allowed_langs))
        return

    session = requests.Session()
    if not login(session, username, password):
        notify("WoSir.cz login failed - check username/password in addon settings.")
        return

    shows = search_site(session, query)
    log("{0} show match(es) for '{1}'".format(len(shows), query))
    if not shows:
        return

    best = pick_best_match(query, shows)
    log("picked show: '{0}' (id={1})".format(best['title'], best['id']))

    try:
        resp = session.get(anime_url(best['id']), headers=HEADERS, timeout=15)
        html_text = resp.text
    except Exception as e:
        log("subtitle table fetch failed: {0}".format(e))
        return

    rows = parse_subtitle_rows(html_text)

    if episode is not None:
        matching = [r for r in rows if r['ep'] == str(episode)]
        if matching:
            rows = matching
        else:
            log("no rows matched episode {0}, showing full list instead".format(episode))

    saved = {}
    shown = 0
    for i, row in enumerate(rows):
        rid = str(i)
        saved[rid] = {
            "ep": row['ep'], "title": row['title'], "is_bd": row['is_bd'],
            "fields": row['fields'], "anime_id": best['id'],
        }
        suffix = " (BD)" if row['is_bd'] else ""
        label2 = "Ep {0}{1} - {2}".format(row['ep'], suffix, row['title'])
        append_subtitle(label2, {"action": "download", "rid": rid})
        shown += 1

    save_rows(saved)
    log("listed {0} subtitle(s) for '{1}'".format(shown, best['title']))

def handle_download(params):
    rid = params.get('rid', [None])[0]
    if rid is None:
        notify("Nothing to download.")
        return
    rows = load_rows()
    entry = rows.get(rid)
    if not entry:
        notify("Subtitle info expired - please search again.")
        return

    username = ADDON.getSetting('username')
    password = ADDON.getSetting('password')
    session = requests.Session()
    if not login(session, username, password):
        notify("Login failed - check username/password in addon settings.")
        return

    url = anime_url(entry['anime_id'])
    # POST exactly the fields the real form on the page would submit
    # (file_to_download[_BD], dwl[_bd], hiddenid) - this is NOT the
    # "Zkopirovat URL" link, a separate decoy code path
    data = {k: html_mod.unescape(v) for k, v in entry['fields'].items()}

    try:
        resp = session.post(url, data=data, headers={**HEADERS, "Referer": url}, timeout=20)
        content = resp.content
    except Exception as e:
        log("download post failed: {0}".format(e))
        notify("Download failed (see debug log).")
        return

    if not content:
        notify("Download failed - empty response (see debug log). Try again in a moment.")
        log("download got empty body for ep {0}".format(entry['ep']))
        return
    sample = content[:200].lstrip()
    if sample.startswith(b'<'):
        notify("Download failed - site returned a page instead of a subtitle.")
        log("download body looked like HTML for ep {0}: {1}".format(entry['ep'], sample[:80]))
        return

    suffix = "_BD" if entry.get('is_bd') else ""
    filename = "wosir_ep{0}{1}_{2}.ass".format(entry['ep'], suffix, int(time.time()))
    filepath = os.path.join(TEMP_DIR, filename)
    try:
        with open(filepath, 'wb') as f:
            f.write(content)
    except Exception as e:
        log("failed to write subtitle file: {0}".format(e))
        notify("Downloaded but couldn't save the file (see debug log).")
        return

    log("saved subtitle to {0}".format(filepath))
    listitem = xbmcgui.ListItem(label=filename)
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=filepath, listitem=listitem, isFolder=False)

def run():
    try:
        params = get_params()
        action = params.get('action', [''])[0]
        log("action={0} params={1}".format(action, params))
        if action == 'search':
            handle_search(params, is_manual=False)
        elif action == 'manualsearch':
            handle_search(params, is_manual=True)
        elif action == 'download':
            handle_download(params)
        else:
            log("unknown/missing action, nothing to do")
    except Exception as e:
        log("unhandled exception: {0}\n{1}".format(e, traceback.format_exc()))
    finally:
        xbmcplugin.endOfDirectory(HANDLE)

if __name__ == '__main__':
    run()
