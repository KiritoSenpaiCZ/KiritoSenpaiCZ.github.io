# -*- coding: utf-8 -*-
"""
WoSir.cz Subtitles - Kodi subtitle service addon.

Site notes:
- Login needs a CSRF token scraped from the login page first, and a
  fresh cookie jar every time (a still-"logged in" cookie makes the
  login page redirect away before a token can be scraped) - done here
  with a brand new requests.Session() per login.
- Everything on this site is Czech - no language column to parse.
- Each row can be a TV or a Blu-ray (BD) release, told apart by which
  hidden form field is present (file_to_download vs
  file_to_download_BD). The real "Stahnout" download button is that
  form's POST - not the separate "Zkopirovat URL" button, which is a
  different code path.
- Logs in fresh on every search and download (no session caching);
  table parsing is content-based, not by fixed column index.

Debugging: enable Kodi's debug log (Settings -> System -> Logging),
reproduce, then look for "[WoSir]" lines in kodi.log.
"""

import difflib
import html as html_mod
import json
import os
import re
import shutil
import sys
import time
import traceback
from urllib.parse import parse_qs, unquote

import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')

PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
TEMP_DIR = xbmcvfs.translatePath(os.path.join(PROFILE, 'temp', ''))
if not xbmcvfs.exists(TEMP_DIR):
    xbmcvfs.mkdirs(TEMP_DIR)
ROWS_FILE = os.path.join(TEMP_DIR, 'wosir_rows.json')
OWNERS_FILE = os.path.join(TEMP_DIR, 'wosir_owners.json')

HANDLE = int(sys.argv[1])

BASE_URL = "https://www.wosir.cz"
HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                  "(KHTML, like Gecko) Chrome/124.0 Safari/537.36"
}

LANG_NAME = "Czech"
LANG_FLAG = "cs"  # ISO 639-1 code Kodi's flag art expects

# Anything left behind in TEMP_DIR older than this gets swept on the next
# run - a search+download round trip finishes in well under a minute, so
# anything still there an hour later is leftover, not in-use.
TEMP_MAX_AGE_SECONDS = 3600
# temp-folder entries this addon creates start with TEMP_FILE_PREFIX;
# KEEP_FILES are never swept
TEMP_FILE_PREFIX = 'wosir_'
KEEP_FILES = {os.path.basename(ROWS_FILE), os.path.basename(OWNERS_FILE)}

# Refuse an implausibly large download - subtitle files are small, so
# hitting this means something's wrong (a huge unexpected response).
MAX_DOWNLOAD_BYTES = 20 * 1024 * 1024

# >>> shared block "kodi_lang" - edit dev/shared/kodi_lang.py in KiritoSenpaiCZ.github.io, then run dev/sync.py
# The addon's messages are in Czech when Kodi's language is Czech or Slovak,
# English otherwise. L("english", "czech", *args) picks one and fills in
# {0}-style placeholders like str.format.
try:
    _UI_LANG = xbmc.getLanguage(xbmc.ISO_639_1)
except Exception:
    _UI_LANG = ''


def L(en, cs, *args):
    text = cs if _UI_LANG in ('cs', 'sk') else en
    return text.format(*args) if args else text
# <<< shared block "kodi_lang"


# ---------------- small helpers ----------------

def log(msg):
    xbmc.log("[WoSir] {0}".format(msg), level=xbmc.LOGDEBUG)

def notify(msg):
    xbmcgui.Dialog().notification(ADDON_NAME, msg, xbmcgui.NOTIFICATION_INFO, 4000)

def get_params():
    raw = sys.argv[2] if len(sys.argv) > 2 else ""
    return parse_qs(raw.lstrip('?'))

def save_rows(rows_dict):
    try:
        with open(ROWS_FILE, 'w', encoding='utf-8') as f:
            json.dump(rows_dict, f)
    except Exception as e:
        log("failed to save rows cache: {0}".format(e))

def load_rows():
    try:
        with open(ROWS_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {}

# >>> shared block "kodi_temp" - edit dev/shared/kodi_temp.py in KiritoSenpaiCZ.github.io, then run dev/sync.py
def current_video():
    """Path of the video Kodi has loaded - playing OR paused - else None.
    (Player.Playing alone isn't enough: it's false while paused.)"""
    try:
        if xbmc.getCondVisibility('Player.HasVideo') or xbmc.getCondVisibility('Player.Paused'):
            return xbmc.getInfoLabel('Player.Filenameandpath') or None
    except Exception:
        pass
    return None


def _read_owners():
    try:
        with open(OWNERS_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _write_owners(owners):
    try:
        with open(OWNERS_FILE, 'w', encoding='utf-8') as f:
            json.dump(owners, f)
    except Exception as e:
        log("couldn't save {0}: {1}".format(OWNERS_FILE, e))


def remember_owner(path):
    """Record which video a delivered subtitle belongs to, so
    cleanup_temp_dir() never deletes it while that video is still loaded
    (e.g. paused for more than an hour)."""
    video = current_video()
    if not video:
        return
    try:
        top = os.path.relpath(path, TEMP_DIR).split(os.sep)[0]
    except ValueError:
        return
    if not top or top.startswith('..'):
        return
    owners = _read_owners()
    owners[top] = video
    _write_owners(owners)


def cleanup_temp_dir():
    """Sweep old downloads out of TEMP_DIR. Kept: KEEP_FILES (small caches
    managed by their own logic), and every subtitle belonging to the video
    Kodi currently has loaded - playing or paused - however old it is, so a
    long pause can't delete a subtitle that's still in use."""
    keep = KEEP_FILES
    owners = _read_owners()
    video = current_video()
    try:
        now = time.time()
        for name in os.listdir(TEMP_DIR):
            if name in keep or not name.startswith(TEMP_FILE_PREFIX):
                continue
            if video and owners.get(name) == video:
                continue
            path = os.path.join(TEMP_DIR, name)
            try:
                age = now - os.path.getmtime(path)
            except OSError:
                continue
            if age < TEMP_MAX_AGE_SECONDS:
                continue
            try:
                if os.path.isdir(path):
                    shutil.rmtree(path, ignore_errors=True)
                else:
                    os.remove(path)
            except OSError as e:
                log("cleanup: couldn't remove {0}: {1}".format(path, e))
        existing = set(os.listdir(TEMP_DIR))
        still_there = dict((k, v) for k, v in owners.items() if k in existing)
        if still_there != owners:
            _write_owners(still_there)
    except Exception as e:
        log("cleanup_temp_dir failed: {0}".format(e))
# <<< shared block "kodi_temp"


# ---------------- title/query cleanup ----------------

def clean_release_title(name):
    if not name:
        return name
    name = re.sub(r'\.\w+$', '', name)
    name = re.sub(r'\[[^\]]*\]', ' ', name)
    name = re.sub(r'\([^)]*\)', ' ', name)
    name = re.sub(r'[._]', ' ', name)

    lower = name.lower()
    cut_at = None
    m = re.search(r's\d{1,2}e\d{1,2}', lower)
    if m:
        cut_at = m.start()
    keywords = [
        "2160p", "1080p", "720p", "480p", "4k",
        "blu-ray", "bluray", "bdrip", "webrip", "web-dl", "web dl",
        "hdtv", "dvdrip", "hdrip",
        "x264", "x265", "h264", "h265", "hevc", "avc",
        "dual audio", "dual-audio", "multi audio", "multi-audio",
        "aac", "flac", "dts", "opus",
    ]
    for kw in keywords:
        idx = lower.find(kw)
        if idx != -1 and (cut_at is None or idx < cut_at):
            cut_at = idx
    if cut_at is not None:
        name = name[:cut_at]

    name = re.sub(r'\s-\s*\d+.*$', '', name)
    name = re.sub(r'[-–—]+\s*$', '', name)
    name = re.sub(r'\s+', ' ', name).strip()
    return name

def extract_season_episode(text):
    if not text:
        return text, None, None
    m = re.search(r'[sS](\d{1,2})[eE](\d{1,3})', text)
    if not m:
        return text, None, None
    season = int(m.group(1))
    episode = int(m.group(2))
    cleaned = (text[:m.start()] + text[m.end():]).strip()
    cleaned = clean_release_title(cleaned) or cleaned
    return cleaned, season, episode

def pick_best_match(query, shows):
    if not shows:
        return None
    titles_lower = [s['title'].lower() for s in shows]
    close = difflib.get_close_matches(query.lower(), titles_lower, n=1, cutoff=0.0)
    if close:
        return shows[titles_lower.index(close[0])]
    return shows[0]

def get_allowed_languages(params):
    raw = params.get('languages', [''])[0]
    if not raw:
        return None
    return set(unquote(n) for n in raw.split(','))

# ---------------- site access ----------------

def extract_attr(attrs, name):
    m = re.search(r'{0}="([^"]*)"'.format(name), attrs)
    return m.group(1) if m else None

def anime_url(anime_id):
    return "{0}/anime.php?id={1}".format(BASE_URL, anime_id)

def login(session, username, password):
    """Fresh login. Session must be a brand-new requests.Session() (no
    leftover cookies), otherwise the CSRF-protected login page can
    redirect away as "already logged in" before a token is scraped."""
    try:
        resp = session.get("{0}/prihlaseni".format(BASE_URL), headers=HEADERS, timeout=15)
        page = resp.text
    except Exception as e:
        log("login page fetch failed: {0}".format(e))
        return False

    csrf = None
    for attrs in re.findall(r'<input\s+([^>]*?)/?>', page):
        if extract_attr(attrs, "name") == "csrf_token":
            csrf = extract_attr(attrs, "value")
            break
    if not csrf:
        log("login: csrf_token not found on login page")

    data = {
        "prezdivka": username,
        "heslo": password,
        "csrf_token": csrf or "",
        "sub": "Přihlásit",
    }
    try:
        resp = session.post(
            "{0}/prihlaseni".format(BASE_URL), data=data,
            headers={**HEADERS, "Referer": "{0}/prihlaseni".format(BASE_URL)},
            timeout=15
        )
        body = resp.text
    except Exception as e:
        log("login post failed: {0}".format(e))
        return False

    return ("odhlásit" in body) or ("logout.php" in body)

def search_site(session, query):
    try:
        resp = session.get(
            "{0}/preklady".format(BASE_URL),
            params={"search": query, "search_sub": "Hledat"},
            headers=HEADERS, timeout=15
        )
        html_text = resp.text
    except Exception as e:
        log("search request failed: {0}".format(e))
        return []
    results = []
    for m in re.finditer(
        r'<a[^>]*?href="[^"]*?anime\?id=(\d+)"[^>]*>.*?<span[^>]*>([^<]+)</span>',
        html_text, re.DOTALL
    ):
        results.append({"id": m.group(1), "title": html_mod.unescape(m.group(2))})
    return results

def parse_inputs(form_html):
    fields = {}
    for attrs in re.findall(r'<input\s+([^>]*?)/?>', form_html):
        name = extract_attr(attrs, "name")
        if name:
            fields[name] = extract_attr(attrs, "value") or ""
    return fields

def parse_subtitle_rows(html_text):
    """Content-based parsing: episode number + title from the td-pair
    adjacency, TV/BD told apart by which hidden
    field is present in the row's real download form (not the visible
    'Blu-ray' text label, which can say other things)."""
    rows = []
    row_count = 0
    skipped = 0
    for row_html in re.findall(r'<tr[^>]*class="[^"]*tsubs[^"]*"[^>]*>.*?</tr>', html_text, re.DOTALL):
        row_count += 1

        ep_title_m = re.search(
            r'<td[^>]*>\s*(\d{1,3})\s*</td>\s*<td[^>]*>\s*(.*?)\s*</td>',
            row_html, re.DOTALL
        )
        ep = ep_title_m.group(1) if ep_title_m else None
        title = "?"
        if ep_title_m:
            title = html_mod.unescape(re.sub(r'<[^>]+>', '', ep_title_m.group(2))).strip() or "?"

        fields = None
        is_bd = False
        for form_html in re.findall(r'<form.*?</form>', row_html, re.DOTALL):
            f = parse_inputs(form_html)
            if 'file_to_download_BD' in f:
                fields, is_bd = f, True
                break
            elif 'file_to_download' in f:
                fields, is_bd = f, False
                break

        if not ep or not fields:
            skipped += 1
            log("skipped row {0} (ep={1} has_fields={2})".format(row_count, ep, fields is not None))
            continue

        rows.append({"ep": ep, "title": title, "is_bd": is_bd, "fields": fields})
        log("row {0} OK: ep={1} bd={2} title={3}".format(row_count, ep, is_bd, title))

    log("parsed {0} <tr class=tsubs> rows, {1} usable, {2} skipped".format(row_count, len(rows), skipped))
    return rows

# ---------------- Kodi-facing actions ----------------

def append_subtitle(label2, url_params):
    listitem = xbmcgui.ListItem(label=LANG_NAME, label2=label2)
    listitem.setArt({"thumb": LANG_FLAG})
    listitem.setProperty("sync", "false")
    listitem.setProperty("hearing_imp", "false")
    url = "plugin://{0}/?{1}".format(
        ADDON_ID,
        "&".join("{0}={1}".format(k, requests.utils.quote(str(v))) for k, v in url_params.items())
    )
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=listitem, isFolder=False)

def handle_search(params, is_manual):
    username = ADDON.getSetting('username')
    password = ADDON.getSetting('password')
    if not username or not password:
        notify(L('Set your wosir.cz username/password in the addon settings.', 'Nastavte své jméno a heslo k wosir.cz v nastavení doplňku.'))
        ADDON.openSettings()
        return

    season = episode = None
    if is_manual:
        query_raw = params.get('searchstring', [''])[0]
        query, season, episode = extract_season_episode(query_raw)
        if not query:
            query = clean_release_title(query_raw)
    else:
        tvshow = xbmc.getInfoLabel("VideoPlayer.TVshowtitle")
        title = tvshow or xbmc.getInfoLabel("VideoPlayer.OriginalTitle") or xbmc.getInfoLabel("VideoPlayer.Title")
        season_label = xbmc.getInfoLabel("VideoPlayer.Season")
        episode_label = xbmc.getInfoLabel("VideoPlayer.Episode")
        if season_label.isdigit():
            season = int(season_label)
        if episode_label.isdigit():
            episode = int(episode_label)

        if title:
            query = clean_release_title(title)
        else:
            try:
                filename = os.path.basename(unquote(xbmc.Player().getPlayingFile()))
            except Exception:
                filename = ""
            query, s2, e2 = extract_season_episode(filename)
            query = clean_release_title(query)
            if season is None:
                season = s2
            if episode is None:
                episode = e2

    query = (query or "").strip()
    if not query:
        log("no usable search query, aborting")
        return

    log("query='{0}' season={1} episode={2} manual={3}".format(query, season, episode, is_manual))

    allowed_langs = get_allowed_languages(params)
    if allowed_langs and LANG_NAME not in allowed_langs:
        log("Czech not in requested languages {0}, nothing to offer".format(allowed_langs))
        return

    session = requests.Session()
    if not login(session, username, password):
        notify(L('WoSir.cz login failed - check username/password in addon settings.', 'Přihlášení k wosir.cz selhalo - zkontrolujte jméno a heslo v nastavení doplňku.'))
        return

    shows = search_site(session, query)
    log("{0} show match(es) for '{1}'".format(len(shows), query))
    if not shows:
        return

    best = pick_best_match(query, shows)
    log("picked show: '{0}' (id={1})".format(best['title'], best['id']))

    try:
        resp = session.get(anime_url(best['id']), headers=HEADERS, timeout=15)
        html_text = resp.text
    except Exception as e:
        log("subtitle table fetch failed: {0}".format(e))
        return

    rows = parse_subtitle_rows(html_text)

    if episode is not None:
        matching = [r for r in rows if r['ep'] == str(episode)]
        if matching:
            rows = matching
        else:
            log("no rows matched episode {0}, showing full list instead".format(episode))

    saved = {}
    shown = 0
    for i, row in enumerate(rows):
        rid = str(i)
        saved[rid] = {
            "ep": row['ep'], "title": row['title'], "is_bd": row['is_bd'],
            "fields": row['fields'], "anime_id": best['id'],
        }
        suffix = " (BD)" if row['is_bd'] else ""
        label2 = "Ep {0}{1} - {2}".format(row['ep'], suffix, row['title'])
        append_subtitle(label2, {"action": "download", "rid": rid})
        shown += 1

    save_rows(saved)
    log("listed {0} subtitle(s) for '{1}'".format(shown, best['title']))

def handle_download(params):
    rid = params.get('rid', [None])[0]
    if rid is None:
        notify(L('Nothing to download.', 'Není co stáhnout.'))
        return
    rows = load_rows()
    entry = rows.get(rid)
    if not entry:
        notify(L('Subtitle info expired - please search again.', 'Údaje o titulcích vypršely - vyhledejte prosím znovu.'))
        return

    username = ADDON.getSetting('username')
    password = ADDON.getSetting('password')
    session = requests.Session()
    if not login(session, username, password):
        notify(L('Login failed - check username/password in addon settings.', 'Přihlášení selhalo - zkontrolujte jméno a heslo v nastavení doplňku.'))
        return

    url = anime_url(entry['anime_id'])
    # POST exactly the fields the real form on the page would submit
    # (file_to_download[_BD], dwl[_bd], hiddenid) - this is NOT the
    # "Zkopirovat URL" link, a separate code path
    data = {k: html_mod.unescape(v) for k, v in entry['fields'].items()}

    try:
        resp = session.post(url, data=data, headers={**HEADERS, "Referer": url}, timeout=20)
        content = resp.content
    except Exception as e:
        log("download post failed: {0}".format(e))
        notify(L('Download failed (see debug log).', 'Stažení selhalo (podrobnosti v logu).'))
        return

    if not content:
        notify(L('Download failed - empty response (see debug log). Try again in a moment.', 'Stažení selhalo - prázdná odpověď (podrobnosti v logu). Zkuste to za chvíli znovu.'))
        log("download got empty body for ep {0}".format(entry['ep']))
        return
    sample = content[:200].lstrip()
    if sample.startswith(b'<'):
        notify(L('Download failed - site returned a page instead of a subtitle.', 'Stažení selhalo - stránka místo titulků vrátila webovou stránku.'))
        log("download body looked like HTML for ep {0}: {1}".format(entry['ep'], sample[:80]))
        return

    if len(content) > MAX_DOWNLOAD_BYTES:
        notify(L('Download refused - file is larger than expected (see debug log).', 'Stažení odmítnuto - soubor je větší, než by měl být (podrobnosti v logu).'))
        log("download refused: {0} bytes exceeds MAX_DOWNLOAD_BYTES {1}".format(
            len(content), MAX_DOWNLOAD_BYTES))
        return

    suffix = "_BD" if entry.get('is_bd') else ""
    filename = "wosir_ep{0}{1}_{2}.ass".format(entry['ep'], suffix, int(time.time()))
    filepath = os.path.join(TEMP_DIR, filename)
    try:
        with open(filepath, 'wb') as f:
            f.write(content)
    except Exception as e:
        log("failed to write subtitle file: {0}".format(e))
        notify(L("Downloaded but couldn't save the file (see debug log).", 'Staženo, ale soubor se nepodařilo uložit (podrobnosti v logu).'))
        return

    remember_owner(filepath)

    log("saved subtitle to {0}".format(filepath))
    listitem = xbmcgui.ListItem(label=filename)
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=filepath, listitem=listitem, isFolder=False)

def run():
    try:
        cleanup_temp_dir()
        params = get_params()
        action = params.get('action', [''])[0]
        log("action={0} params={1}".format(action, params))
        if action == 'search':
            handle_search(params, is_manual=False)
        elif action == 'manualsearch':
            handle_search(params, is_manual=True)
        elif action == 'download':
            handle_download(params)
        else:
            log("unknown/missing action, nothing to do")
    except Exception as e:
        log("unhandled exception: {0}\n{1}".format(e, traceback.format_exc()))
    finally:
        xbmcplugin.endOfDirectory(HANDLE)

if __name__ == '__main__':
    run()
