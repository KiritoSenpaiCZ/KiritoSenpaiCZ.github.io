# -*- coding: utf-8 -*-
"""
Edna.cz Subtitles - Kodi subtitle service addon.

Site notes:
  - edna.cz has a show -> season -> episode hierarchy. Each search resolves
    it: find the show, then fetch the season's episode list (the season
    comes from Kodi's video metadata, a manual "S01E02"-style query, or
    defaults to 1), then filter to the matching episode.
  - The season/episode listing requires being logged in.
  - Each episode can have 0, 1 or 2 subtitle flags (Czech/Slovak), each
    pointing either to an edna.cz page (internal, downloadable) or straight
    to titulky.com (external).
  - An internal page's real file is its "?direct=1" link. It can be a raw
    .srt/.ass or a .zip, so the download step handles both.
  - External subtitles are listed but never downloaded; selecting one shows
    the titulky.com link instead.
  - Whole-season bulk download ("Celá sezóna") is deliberately not
    supported.
  - Logs in fresh on every search and download (each Kodi call is its own
    process, so there's no session to reuse).

Debugging: enable Kodi's debug log (Settings -> System -> Logging),
reproduce, then look for "[Edna]" lines in kodi.log.
"""

import difflib
import html as html_mod
import json
import os
import re
import shutil
import sys
import time
import traceback
import zipfile
from urllib.parse import parse_qs, unquote

import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')

PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
TEMP_DIR = xbmcvfs.translatePath(os.path.join(PROFILE, 'temp', ''))
if not xbmcvfs.exists(TEMP_DIR):
    xbmcvfs.mkdirs(TEMP_DIR)
ROWS_FILE = os.path.join(TEMP_DIR, 'edna_rows.json')
OWNERS_FILE = os.path.join(TEMP_DIR, 'edna_owners.json')

HANDLE = int(sys.argv[1])

BASE_URL = "https://www.edna.cz"
HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                  "(KHTML, like Gecko) Chrome/124.0 Safari/537.36"
}
# The login POST needs these extra headers or edna.cz's anti-bot layer
# rejects it even with correct credentials. Only added to the login POST,
# not plain GETs.
# Minimum time between loading edna.cz's login form and submitting it (see
# login() - its anti-spam add-on rejects faster submissions as bots).
LOGIN_FORM_DELAY_SECONDS = 6

LOGIN_EXTRA_HEADERS = {
    "Origin": BASE_URL,
    "Accept-Language": "cs-CZ,cs;q=0.9,en;q=0.8",
    "Sec-Fetch-Site": "same-origin",
    "Sec-Fetch-Mode": "navigate",
    "Sec-Fetch-User": "?1",
    "Sec-Fetch-Dest": "document",
}

LANG_NAMES = {"CZ": "Czech", "SK": "Slovak"}
LANG_FLAGS = {"CZ": "cs", "SK": "sk"}  # ISO 639-1 codes Kodi's flag art expects

# Anything left behind in TEMP_DIR older than this gets swept on the next
# run - a search+download round trip finishes in well under a minute, so
# anything still there an hour later is leftover, not in-use.
TEMP_MAX_AGE_SECONDS = 3600
# temp-folder entries this addon creates start with TEMP_FILE_PREFIX;
# KEEP_FILES are never swept
TEMP_FILE_PREFIX = 'edna_'
KEEP_FILES = {os.path.basename(ROWS_FILE), os.path.basename(OWNERS_FILE)}

# Refuse an implausibly large download or an implausibly large *extracted*
# zip - subtitle files/packs are small, so either cap being hit means
# something's wrong (a huge unexpected response, or a zip bomb).
MAX_DOWNLOAD_BYTES = 20 * 1024 * 1024
MAX_EXTRACTED_BYTES = 200 * 1024 * 1024


# >>> shared block "kodi_lang" - edit dev/shared/kodi_lang.py in KiritoSenpaiCZ.github.io, then run dev/sync.py
# The addon's messages are in Czech when Kodi's language is Czech or Slovak,
# English otherwise. L("english", "czech", *args) picks one and fills in
# {0}-style placeholders like str.format.
try:
    _UI_LANG = xbmc.getLanguage(xbmc.ISO_639_1)
except Exception:
    _UI_LANG = ''


def L(en, cs, *args):
    text = cs if _UI_LANG in ('cs', 'sk') else en
    return text.format(*args) if args else text
# <<< shared block "kodi_lang"


# ---------------- small helpers ----------------

def log(msg):
    xbmc.log("[Edna] {0}".format(msg), level=xbmc.LOGDEBUG)


def notify(msg):
    xbmcgui.Dialog().notification(ADDON_NAME, msg, xbmcgui.NOTIFICATION_INFO, 4000)


def get_params():
    raw = sys.argv[2] if len(sys.argv) > 2 else ""
    return parse_qs(raw.lstrip('?'))


def save_rows(rows_dict):
    try:
        with open(ROWS_FILE, 'w', encoding='utf-8') as f:
            json.dump(rows_dict, f)
    except Exception as e:
        log("failed to save rows cache: {0}".format(e))


def load_rows():
    try:
        with open(ROWS_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {}


# >>> shared block "kodi_temp" - edit dev/shared/kodi_temp.py in KiritoSenpaiCZ.github.io, then run dev/sync.py
def current_video():
    """Path of the video Kodi has loaded - playing OR paused - else None.
    (Player.Playing alone isn't enough: it's false while paused.)"""
    try:
        if xbmc.getCondVisibility('Player.HasVideo') or xbmc.getCondVisibility('Player.Paused'):
            return xbmc.getInfoLabel('Player.Filenameandpath') or None
    except Exception:
        pass
    return None


def _read_owners():
    try:
        with open(OWNERS_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _write_owners(owners):
    try:
        with open(OWNERS_FILE, 'w', encoding='utf-8') as f:
            json.dump(owners, f)
    except Exception as e:
        log("couldn't save {0}: {1}".format(OWNERS_FILE, e))


def remember_owner(path):
    """Record which video a delivered subtitle belongs to, so
    cleanup_temp_dir() never deletes it while that video is still loaded
    (e.g. paused for more than an hour)."""
    video = current_video()
    if not video:
        return
    try:
        top = os.path.relpath(path, TEMP_DIR).split(os.sep)[0]
    except ValueError:
        return
    if not top or top.startswith('..'):
        return
    owners = _read_owners()
    owners[top] = video
    _write_owners(owners)


def cleanup_temp_dir():
    """Sweep old downloads out of TEMP_DIR. Kept: KEEP_FILES (small caches
    managed by their own logic), and every subtitle belonging to the video
    Kodi currently has loaded - playing or paused - however old it is, so a
    long pause can't delete a subtitle that's still in use."""
    keep = KEEP_FILES
    owners = _read_owners()
    video = current_video()
    try:
        now = time.time()
        for name in os.listdir(TEMP_DIR):
            if name in keep or not name.startswith(TEMP_FILE_PREFIX):
                continue
            if video and owners.get(name) == video:
                continue
            path = os.path.join(TEMP_DIR, name)
            try:
                age = now - os.path.getmtime(path)
            except OSError:
                continue
            if age < TEMP_MAX_AGE_SECONDS:
                continue
            try:
                if os.path.isdir(path):
                    shutil.rmtree(path, ignore_errors=True)
                else:
                    os.remove(path)
            except OSError as e:
                log("cleanup: couldn't remove {0}: {1}".format(path, e))
        existing = set(os.listdir(TEMP_DIR))
        still_there = dict((k, v) for k, v in owners.items() if k in existing)
        if still_there != owners:
            _write_owners(still_there)
    except Exception as e:
        log("cleanup_temp_dir failed: {0}".format(e))
# <<< shared block "kodi_temp"


def extract_attr(attrs, name):
    m = re.search(r'{0}="([^"]*)"'.format(name), attrs)
    return m.group(1) if m else None


# ---------------- title/query cleanup ----------------

def clean_release_title(name):
    """Strip season/episode markers and release-scene tags from a raw
    filename/title."""
    if not name:
        return name
    name = re.sub(r'\.\w+$', '', name)          # extension
    name = re.sub(r'\[[^\]]*\]', ' ', name)      # [tags]
    name = re.sub(r'\([^)]*\)', ' ', name)       # (tags)
    name = re.sub(r'[._]', ' ', name)            # dots/underscores -> spaces

    lower = name.lower()
    cut_at = None
    m = re.search(r's\d{1,2}e\d{1,2}', lower)
    if m:
        cut_at = m.start()
    keywords = [
        "2160p", "1080p", "720p", "480p", "4k",
        "blu-ray", "bluray", "bdrip", "webrip", "web-dl", "web dl",
        "hdtv", "dvdrip", "hdrip",
        "x264", "x265", "h264", "h265", "hevc", "avc",
        "dual audio", "dual-audio", "multi audio", "multi-audio",
        "aac", "flac", "dts", "opus",
    ]
    for kw in keywords:
        idx = lower.find(kw)
        if idx != -1 and (cut_at is None or idx < cut_at):
            cut_at = idx
    if cut_at is not None:
        name = name[:cut_at]

    name = re.sub(r'\s-\s*\d+.*$', '', name)     # trailing "- 05..." marker
    name = re.sub(r'[-–—]+\s*$', '', name)  # leftover trailing dash (-, en dash, em dash)
    name = re.sub(r'\s+', ' ', name).strip()
    return name


def extract_season_episode(text):
    """Pull a leading/embedded 'S01E02' style marker out of a string
    (mainly for Kodi's manual-search box), returning (cleaned_text,
    season, episode)."""
    if not text:
        return text, None, None
    m = re.search(r'[sS](\d{1,2})[eE](\d{1,3})', text)
    if not m:
        return text, None, None
    season = int(m.group(1))
    episode = int(m.group(2))
    cleaned = (text[:m.start()] + text[m.end():]).strip()
    cleaned = clean_release_title(cleaned) or cleaned
    return cleaned, season, episode


def pick_best_match(query, shows):
    """Case-insensitive closest-title match (a case-sensitive match misses
    real, known shows)."""
    if not shows:
        return None
    titles_lower = [s['title'].lower() for s in shows]
    close = difflib.get_close_matches(query.lower(), titles_lower, n=1, cutoff=0.0)
    if close:
        return shows[titles_lower.index(close[0])]
    return shows[0]


def get_allowed_languages(params):
    raw = params.get('languages', [''])[0]
    if not raw:
        return None
    return set(unquote(n) for n in raw.split(','))


# ---------------- site access ----------------

def login(session, username, password):
    """Fresh login on a brand-new requests.Session(): a freshly rendered
    login form is needed to get a valid form_created token."""
    try:
        # visit the homepage first, like a real visitor would, before the
        # login page itself - a real login carries cookies handed out during
        # general browsing, not just from the login page.
        session.get(BASE_URL + "/", headers=HEADERS, timeout=15)
        resp = session.get(BASE_URL + "/uzivatel/prihlaseni/", headers=HEADERS, timeout=15)
        login_page = resp.text
    except Exception as e:
        log("login page fetch failed: {0}".format(e))
        return False

    form_created = None
    for attrs in re.findall(r'<input\s+([^>]*?)/?>', login_page):
        if extract_attr(attrs, "name") == "form_created":
            form_created = extract_attr(attrs, "value")
            break
    if not form_created:
        log("login: form_created token not found on login page")

    data = {
        "spam": "",
        "nick": username,
        "password": password,
        "send": "Přihlásit se",
        "form_created": form_created or "",
    }
    headers = dict(HEADERS)
    headers.update(LOGIN_EXTRA_HEADERS)
    headers["Referer"] = BASE_URL + "/uzivatel/prihlaseni/"

    # Edna's login form uses the Nette AntiSpam add-on: form_created encodes
    # when the form was rendered (9999999999 minus the unix time, digits
    # written as letters a-j), and a form submitted only moments later is
    # rejected as a bot ("Byl detekován pokus o spam"). Wait like a person
    # filling it in would. A fixed wait, not
    # one computed from the token, so a wrong local clock can't break it.
    log("login: waiting {0}s before submitting (anti-spam form timer)".format(LOGIN_FORM_DELAY_SECONDS))
    xbmc.sleep(LOGIN_FORM_DELAY_SECONDS * 1000)

    try:
        resp = session.post(
            BASE_URL + "/uzivatel/prihlaseni/?do=loginForm-submit",
            data=data, headers=headers, timeout=15
        )
        body = resp.text
    except Exception as e:
        log("login post failed: {0}".format(e))
        return False

    ok = ("do=logout" in body) or ("Odhlásit" in body)
    log("login {0} (response {1} bytes)".format("succeeded" if ok else "failed", len(body)))
    return ok


def parse_search_results(html_text):
    """Returns [{title, path}] - only the 'Seriály' (TV series) section of
    the search results, since movies don't have the season/episode
    structure this addon needs."""
    results = []
    start_idx = html_text.find('<h2 class="pushed">Seriály</h2>')
    if start_idx == -1:
        return results
    end_idx = html_text.find('<h2', start_idx + 1)
    if end_idx == -1:
        end_idx = len(html_text)
    section = html_text[start_idx:end_idx]
    for m in re.finditer(r'<h3 class="h4"><a href="([^"]+)">([^<]+)</a></h3>', section):
        results.append({"path": m.group(1), "title": html_mod.unescape(m.group(2))})
    return results


def search_site(session, query):
    try:
        resp = session.get(BASE_URL + "/vyhledavani/", params={"q": query}, headers=HEADERS, timeout=15)
        html_text = resp.text
    except Exception as e:
        log("search request failed: {0}".format(e))
        return []
    return parse_search_results(html_text)


def fetch_episodes(session, show_path, season):
    """Returns [{ep_label, lang, href, internal}] - one entry per
    (episode, language) subtitle flag found on that season's page."""
    url = "{0}{1}titulky/?season={2}".format(BASE_URL, show_path, season)
    try:
        resp = session.get(url, headers=HEADERS, timeout=15)
        html_text = resp.text
    except Exception as e:
        log("episode list request failed: {0}".format(e))
        return []
    return parse_episodes(html_text)


def parse_episodes(html_text):
    rows = []
    row_count = 0
    flag_count = 0
    for row_html in re.findall(r'<tr.*?</tr>', html_text, re.DOTALL):
        row_count += 1
        ep_m = re.search(r'(S\d{1,2}E\d{1,2}:\s*[^<]*?)</a>', row_html)
        if not ep_m:
            continue
        ep_label = html_mod.unescape(ep_m.group(1)).strip()
        for attrs, lang in re.findall(r'<a\s+([^>]*?)>\s*<i class="flag-(\w\w)"', row_html):
            href = extract_attr(attrs, "href")
            if not href:
                continue
            flag_count += 1
            internal = href.startswith('/')
            full_href = (BASE_URL + href) if internal else href
            rows.append({
                "ep_label": ep_label,
                "lang": lang.upper(),
                "href": full_href,
                "internal": internal,
            })
    log("parsed {0} <tr> rows, {1} subtitle flag(s) found".format(row_count, flag_count))
    return rows


def guess_extension(content_disposition, body_sample):
    m = re.search(r'filename\*?=[^\'"]*[\'"]?([^\'";\r\n]+)', content_disposition or "")
    if m:
        ext_m = re.search(r'\.([A-Za-z]+)$', m.group(1))
        if ext_m:
            return "." + ext_m.group(1)
    try:
        sample_text = body_sample.decode('utf-8', 'ignore')
    except Exception:
        sample_text = ""
    if sample_text.strip().startswith("[Script Info]"):
        return ".ass"
    return ".srt"


# ---------------- Kodi-facing actions ----------------

def append_subtitle(lang_name, flag_code, label2, url_params):
    listitem = xbmcgui.ListItem(label=lang_name, label2=label2)
    if flag_code:
        listitem.setArt({"thumb": flag_code})
    listitem.setProperty("sync", "false")
    listitem.setProperty("hearing_imp", "false")
    url = "plugin://{0}/?{1}".format(
        ADDON_ID,
        "&".join("{0}={1}".format(k, requests.utils.quote(str(v))) for k, v in url_params.items())
    )
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=listitem, isFolder=False)


def handle_search(params, is_manual):
    username = ADDON.getSetting('username')
    password = ADDON.getSetting('password')
    if not username or not password:
        notify(L('Set your edna.cz username/password in the addon settings.', 'Nastavte své jméno a heslo k edna.cz v nastavení doplňku.'))
        ADDON.openSettings()
        return

    season = episode = None
    if is_manual:
        query_raw = params.get('searchstring', [''])[0]
        query, season, episode = extract_season_episode(query_raw)
        if not query:
            query = clean_release_title(query_raw)
    else:
        tvshow = xbmc.getInfoLabel("VideoPlayer.TVshowtitle")
        title = tvshow or xbmc.getInfoLabel("VideoPlayer.OriginalTitle") or xbmc.getInfoLabel("VideoPlayer.Title")
        season_label = xbmc.getInfoLabel("VideoPlayer.Season")
        episode_label = xbmc.getInfoLabel("VideoPlayer.Episode")
        if season_label.isdigit():
            season = int(season_label)
        if episode_label.isdigit():
            episode = int(episode_label)

        if title:
            query = clean_release_title(title)
        else:
            # fallback for unscraped local files: clean up the raw filename
            try:
                filename = os.path.basename(unquote(xbmc.Player().getPlayingFile()))
            except Exception:
                filename = ""
            query, s2, e2 = extract_season_episode(filename)
            query = clean_release_title(query)
            if season is None:
                season = s2
            if episode is None:
                episode = e2

    query = (query or "").strip()
    if not query:
        log("no usable search query, aborting")
        return

    # edna.cz always has a season 1 for any show with subtitles - fall back to it
    # whenever Kodi's metadata or the manual query didn't name one.
    if season is None:
        season = 1

    log("query='{0}' season={1} episode={2} manual={3}".format(query, season, episode, is_manual))

    session = requests.Session()
    if not login(session, username, password):
        notify(L('Edna.cz login failed - check username/password in addon settings.', 'Přihlášení k edna.cz selhalo - zkontrolujte jméno a heslo v nastavení doplňku.'))
        return

    shows = search_site(session, query)
    log("{0} show match(es) for '{1}'".format(len(shows), query))
    if not shows:
        return

    best = pick_best_match(query, shows)
    log("picked show: '{0}' (path={1})".format(best['title'], best['path']))

    rows = fetch_episodes(session, best['path'], season)

    if episode is not None:
        target = "S{0:02d}E{1:02d}".format(season, episode)
        matching = [r for r in rows if r['ep_label'].upper().startswith(target)]
        if matching:
            rows = matching
        else:
            log("no rows matched {0}, showing full season {1} list instead".format(target, season))

    allowed_langs = get_allowed_languages(params)
    saved = {}
    shown = 0
    for i, row in enumerate(rows):
        lang_name = LANG_NAMES.get(row['lang'], row['lang'])
        if allowed_langs and lang_name not in allowed_langs:
            continue
        rid = str(i)
        saved[rid] = row
        prefix = "" if row['internal'] else L("[EXTERNAL] ", "[EXTERNÍ] ")
        label2 = "{0}{1}".format(prefix, row['ep_label'])
        append_subtitle(lang_name, LANG_FLAGS.get(row['lang'], ''), label2, {"action": "download", "rid": rid})
        shown += 1

    save_rows(saved)
    log("listed {0} subtitle(s) for '{1}' season {2}".format(shown, best['title'], season))


def handle_download(params):
    rid = params.get('rid', [None])[0]
    if rid is None:
        notify(L('Nothing to download.', 'Není co stáhnout.'))
        return
    rows = load_rows()
    row = rows.get(rid)
    if not row:
        notify(L('Subtitle info expired - please search again.', 'Údaje o titulcích vypršely - vyhledejte prosím znovu.'))
        return

    if not row.get('internal', True):
        # external/forwarded subtitle - never auto-downloaded (it's hosted
        # on titulky.com, a separate site with its own login)
        xbmcgui.Dialog().textviewer(L('External subtitle link (titulky.com)', 'Odkaz na externí titulky (titulky.com)'), row['href'])
        log("external subtitle link shown: {0}".format(row['href']))
        return

    username = ADDON.getSetting('username')
    password = ADDON.getSetting('password')
    session = requests.Session()
    if not login(session, username, password):
        notify(L('Login failed - check username/password in addon settings.', 'Přihlášení selhalo - zkontrolujte jméno a heslo v nastavení doplňku.'))
        return

    # row['href'] is the episode's titulky page (with a "#content" fragment
    # only meaningful in a browser) - the real file is that same page's
    # "?direct=1" fallback link.
    direct_url = re.sub(r'#.*$', '', row['href']) + "?direct=1"

    try:
        resp = session.get(direct_url, headers=HEADERS, timeout=20)
        content = resp.content
        content_disposition = resp.headers.get('Content-Disposition', '')
    except Exception as e:
        log("download failed: {0}".format(e))
        notify(L('Download failed (see debug log).', 'Stažení selhalo (podrobnosti v logu).'))
        return

    if not content or content.lstrip()[:1] == b'<':
        notify(L('Download failed - unexpected response (see debug log). Try again in a moment.', 'Stažení selhalo - neočekávaná odpověď (podrobnosti v logu). Zkuste to za chvíli znovu.'))
        log("download got empty/HTML body for {0} [{1}]".format(row['ep_label'], row['lang']))
        return

    if len(content) > MAX_DOWNLOAD_BYTES:
        notify(L('Download refused - file is larger than expected (see debug log).', 'Stažení odmítnuto - soubor je větší, než by měl být (podrobnosti v logu).'))
        log("download refused: {0} bytes exceeds MAX_DOWNLOAD_BYTES {1}".format(
            len(content), MAX_DOWNLOAD_BYTES))
        return

    safe_name = re.sub(r'[^\w]+', '_', row['ep_label']) + "_" + row['lang']
    is_zip = content[:2] == b'PK'

    if is_zip:
        # some downloads are a zip of .srt files
        zip_path = os.path.join(TEMP_DIR, "edna_{0}_{1}.zip".format(safe_name, int(time.time())))
        try:
            with open(zip_path, 'wb') as f:
                f.write(content)
        except Exception as e:
            log("failed to write zip file: {0}".format(e))
            notify(L("Downloaded but couldn't save the file (see debug log).", 'Staženo, ale soubor se nepodařilo uložit (podrobnosti v logu).'))
            return

        extract_dir = os.path.join(TEMP_DIR, "edna_{0}_{1}".format(safe_name, int(time.time())))
        try:
            with zipfile.ZipFile(zip_path) as zf:
                extracted_size = sum(info.file_size for info in zf.infolist())
                if extracted_size > MAX_EXTRACTED_BYTES:
                    notify(L('Download refused - archive is larger than expected when extracted (see debug log).', 'Stažení odmítnuto - archiv by byl po rozbalení příliš velký (podrobnosti v logu).'))
                    log("refusing to extract {0}: extracted size {1} exceeds MAX_EXTRACTED_BYTES {2}".format(
                        zip_path, extracted_size, MAX_EXTRACTED_BYTES))
                    return
                zf.extractall(extract_dir)
        except Exception as e:
            log("zip extract failed: {0}".format(e))
            notify(L("Downloaded a zip but couldn't extract it (see debug log).", 'ZIP se stáhl, ale nepodařilo se ho rozbalit (podrobnosti v logu).'))
            return

        sub_file = None
        for root, _dirs, files in os.walk(extract_dir):
            for fn in files:
                if fn.lower().endswith(('.srt', '.ass', '.sub')):
                    sub_file = os.path.join(root, fn)
                    break
            if sub_file:
                break
        if not sub_file:
            notify(L('Downloaded and extracted, but no .srt/.ass file found inside.', 'Staženo a rozbaleno, ale uvnitř není žádný soubor .srt/.ass.'))
            log("no subtitle file found after extracting {0}".format(zip_path))
            return
        filepath = sub_file
    else:
        ext = guess_extension(content_disposition, content[:200])
        filename = "edna_{0}_{1}{2}".format(safe_name, int(time.time()), ext)
        filepath = os.path.join(TEMP_DIR, filename)
        try:
            with open(filepath, 'wb') as f:
                f.write(content)
        except Exception as e:
            log("failed to write subtitle file: {0}".format(e))
            notify(L("Downloaded but couldn't save the file (see debug log).", 'Staženo, ale soubor se nepodařilo uložit (podrobnosti v logu).'))
            return

    remember_owner(filepath)

    log("saved subtitle to {0}".format(filepath))
    listitem = xbmcgui.ListItem(label=os.path.basename(filepath))
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=filepath, listitem=listitem, isFolder=False)


def run():
    try:
        cleanup_temp_dir()
        params = get_params()
        action = params.get('action', [''])[0]
        log("action={0} params={1}".format(action, params))
        if action == 'search':
            handle_search(params, is_manual=False)
        elif action == 'manualsearch':
            handle_search(params, is_manual=True)
        elif action == 'download':
            handle_download(params)
        else:
            log("unknown/missing action, nothing to do")
    except Exception as e:
        log("unhandled exception: {0}\n{1}".format(e, traceback.format_exc()))
    finally:
        xbmcplugin.endOfDirectory(HANDLE)


if __name__ == '__main__':
    run()
