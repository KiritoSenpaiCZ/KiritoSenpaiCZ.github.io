# Edna Subtitles - Kodi Subtitle Addon

Kodi subtitle service addon for edna.cz — Czech/Slovak TV show subtitles.

Compatible with Kodi 19, 20, and 21.

## Current Version
service.subtitles.edna - 1.2.0

## Installation Instructions
Recommended: install through the [Highflight Subtitles Repository](https://github.com/KiritoSenpaiCZ/KiritoSenpaiCZ.github.io), which also handles updates.

Manual install:
1. Download `service.subtitles.edna-1.2.0.zip` from this repo (or build it from source)
2. In Kodi: **Add-ons > Install from zip file**, select the zip

## Setup Instructions
1. In Kodi, open this addon's settings
2. Enter your edna.cz username and password

## How it works
- Messages and settings are in Czech when Kodi is set to Czech or Slovak, and in English otherwise
- Searches edna.cz using the show title from Kodi's video metadata (or a manual search), resolving season/episode automatically
- Lists available subtitles, including ones hosted on titulky.com (shown as a link, not auto-downloaded)
- TV series only — edna.cz doesn't organize movie subtitles this way; whole-season bulk download isn't supported
- Logs in fresh on every search/download — no session is cached
- Downloaded files are validated before use (rejects HTML error pages and oversized responses/archives) and old temp files are swept automatically

## Issues
Please open an issue in this repo with a description of the problem and, if possible, a Kodi debug log (Settings > System > Logging > Enable debug logging, then grep `kodi.log` for `[Edna]`).
