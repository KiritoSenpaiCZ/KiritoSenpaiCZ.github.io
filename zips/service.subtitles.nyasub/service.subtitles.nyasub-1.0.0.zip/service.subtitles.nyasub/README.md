# Kodi-NyaSub

A Kodi subtitle addon (`service.subtitles.nyasub`) for [NyaSub](https://nyasub.cz/) — Czech anime subtitles.

## What it does

- Matches Kodi's video metadata (show title, season, episode) - or a manual search - against NyaSub's small, hand-curated "Hotové titulky" catalog
- Downloads the matching episode's subtitle directly - **no account, login or password of any kind needed**, the whole site is public
- Whole-series RAR pack download is not supported - not needed for personal use

## Installation

1. Download the repo as a zip, or build `service.subtitles.nyasub-1.0.0.zip` from this repo's contents
2. In Kodi: **Add-ons → Install from zip file**, select the zip

## How it works

- The catalog (anime title → season/movie page links) is read from `/hotove-preklady/` and cached locally for 24h
- Each season/movie page's episode download links (`?wpdmdl=<id>&masterkey=<key>`) are already baked into the page HTML in on-screen episode order - no click/JS/AJAX needed to obtain them, so episode number is taken from that order rather than parsed page markup
- No session/login caching needed at all - there's no login

### A known rough edge

The site's download endpoint was observed (during testing) to occasionally report a non-200 HTTP status on a request that still visibly succeeded server-side. The addon retries once automatically and accepts any non-empty, non-HTML response rather than trusting the status code alone. If a download still fails after that, please open an issue with the debug log (`grep kodi.log` for `[NyaSub]`).

## Related

- [Kodi-Hiyori](https://github.com/KiritoSenpaiCZ/Kodi-Hiyori) — hiyori.cz
- [Kodi-Wosir](https://github.com/KiritoSenpaiCZ/Kodi-Wosir) — wosir.cz
- [Kodi-Edna](https://github.com/KiritoSenpaiCZ/Kodi-Edna) — edna.cz
- [Kodi-Kamui](https://github.com/KiritoSenpaiCZ/Kodi-Kamui) — kamui-subs.cz
- [Kodi-LegieKondor](https://github.com/KiritoSenpaiCZ/Kodi-LegieKondor) — anime4.legiekondor.cz
