# -*- coding: utf-8 -*-
"""
NyaSub (nyasub.cz) Subtitle Downloader - Kodi subtitle service addon.

Site specifics (confirmed live while building this addon):
  - No account/login needed - the whole site (a public WordPress blog
    using the "Download Manager" / WPDM plugin) is browsable and
    downloadable without one.
  - Catalog: /hotove-preklady/ ("Hotove titulky") lists every finished
    (or in-progress) anime as an <h2> heading, each followed by one or
    more links to that title's season/movie/OVA page(s) (labelled things
    like "1.serie", "2.serie", "cast prvni", or a film/OVA name for
    single-release titles) - a small, hand-curated list (~25 titles at
    build time), not a search engine.
  - Each season/movie page lists its episodes via the WPDM "Download
    Manager" plugin, rendered as an Elementor page (not a plain HTML
    <table>), so there's no reliable structural tag to key episode
    number off of. What IS reliable: every episode's "Titulky" button is
    a plain, pre-rendered <a href="...?wpdmdl=<id>&masterkey=<key>">
    already baked into the page HTML in on-screen episode order - no
    click/JS/AJAX needed to obtain it. This addon relies on that episode
    order (episode N = the Nth such link on the page) rather than trying
    to parse Elementor's markup for episode numbers directly.
  - That wpdmdl+masterkey URL is a complete, ready-to-fetch download
    link - confirmed live (real browser click, WPDM's own download
    counter incrementing 516 -> 517 -> ... after each real click) to
    actually serve the subtitle file. NOTE: the browser's own network
    inspector oddly reported "503" on that same request every time, even
    on the clicks that verifiably succeeded (the counter still went up) -
    unexplained, possibly a quirk of the browser extension's request
    tracking. Because of that ambiguity, the HTTP status code is treated
    as advisory here, not authoritative: a response is accepted as long
    as it isn't empty and doesn't look like an HTML error page, with one
    automatic retry first.
  - The actual downloaded file's exact format (plain .srt/.ass vs a
    zip) could NOT be directly confirmed (every attempt to inspect the
    raw bytes was blocked by a tool-side safety filter, unrelated to the
    site itself) - the site UI shows "File Count: 1" and a ~44 KB size
    for a single episode, consistent with a plain subtitle file, but
    this is inferred, not verified. Handled defensively either way (see
    guess_extension/is_zip below, same pattern as Edna/Hiyori).

Design choices carried over on purpose from Hiyori/WoSir/Edna/Legie Kondor:
  - The catalog (title -> season/movie page links) is cached to disk for
    24h - it's a single page fetch, but caching avoids re-parsing it on
    every search.
  - Content-based parsing rather than fixed structure assumptions.
  - Heavy debug logging via log() - enable Kodi's debug log
    (Settings -> System -> Logging), reproduce, then grep kodi.log for
    "[NyaSub]" and paste the lines back for troubleshooting.
"""

import difflib
import html as html_mod
import json
import os
import re
import shutil
import sys
import time
import traceback
import zipfile
from urllib.parse import parse_qs, unquote

import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')

PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
TEMP_DIR = xbmcvfs.translatePath(os.path.join(PROFILE, 'temp', ''))
if not xbmcvfs.exists(TEMP_DIR):
    xbmcvfs.mkdirs(TEMP_DIR)
ROWS_FILE = os.path.join(TEMP_DIR, 'nyasub_rows.json')
OWNERS_FILE = os.path.join(TEMP_DIR, 'nyasub_owners.json')
CATALOG_FILE = os.path.join(TEMP_DIR, 'nyasub_catalog.json')
CATALOG_TTL = 24 * 60 * 60  # 24h - small hand-curated catalog, changes rarely

HANDLE = int(sys.argv[1])

BASE_URL = "https://nyasub.cz"
CATALOG_URL = BASE_URL + "/hotove-preklady/"
HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                  "(KHTML, like Gecko) Chrome/124.0 Safari/537.36"
}

LANG_NAME = "Czech"
LANG_FLAG = "cs"

# Anything left behind in TEMP_DIR older than this gets swept on the next
# run - a search+download round trip finishes in well under a minute, so
# anything still there an hour later is leftover, not in-use.
TEMP_MAX_AGE_SECONDS = 3600

# Refuse an implausibly large download or an implausibly large *extracted*
# zip - subtitle files/packs are small, so either cap being hit means
# something's wrong (a huge unexpected response, or a zip bomb).
MAX_DOWNLOAD_BYTES = 20 * 1024 * 1024
MAX_EXTRACTED_BYTES = 200 * 1024 * 1024

# Season/part links use varied Czech labels ("1.serie", "cast prvni",
# a film/OVA title, ...) - only the leading "N.serie"/"N. serie" form is
# parsed into an actual season number; anything else is treated as an
# unnumbered release (matched by position only, see pick_season_entry()).
SEASON_LABEL_RE = re.compile(r'^\s*(\d+)\s*\.\s*s[ée]rie', re.IGNORECASE)


# ---------------- small helpers ----------------

def log(msg):
    xbmc.log("[NyaSub] {0}".format(msg), level=xbmc.LOGDEBUG)


def notify(msg):
    xbmcgui.Dialog().notification(ADDON_NAME, msg, xbmcgui.NOTIFICATION_INFO, 4000)


def get_params():
    raw = sys.argv[2] if len(sys.argv) > 2 else ""
    return parse_qs(raw.lstrip('?'))


def save_json(path, data):
    try:
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(data, f)
    except Exception as e:
        log("failed to save {0}: {1}".format(path, e))


def load_json(path):
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return None


def current_video():
    """Path of the video Kodi has loaded - playing OR paused - else None.
    (Player.Playing alone isn't enough: it's false while paused.)"""
    try:
        if xbmc.getCondVisibility('Player.HasVideo') or xbmc.getCondVisibility('Player.Paused'):
            return xbmc.getInfoLabel('Player.Filenameandpath') or None
    except Exception:
        pass
    return None


def _read_owners():
    try:
        with open(OWNERS_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _write_owners(owners):
    try:
        with open(OWNERS_FILE, 'w', encoding='utf-8') as f:
            json.dump(owners, f)
    except Exception as e:
        log("couldn't save {0}: {1}".format(OWNERS_FILE, e))


def remember_owner(path):
    """Record which video a delivered subtitle belongs to, so
    cleanup_temp_dir() never deletes it while that video is still loaded
    (e.g. paused for more than an hour) - suggested by Hanabi's API
    maintainer."""
    video = current_video()
    if not video:
        return
    try:
        top = os.path.relpath(path, TEMP_DIR).split(os.sep)[0]
    except ValueError:
        return
    if not top or top.startswith('..'):
        return
    owners = _read_owners()
    owners[top] = video
    _write_owners(owners)


def cleanup_temp_dir():
    """Sweep old downloads out of TEMP_DIR (they used to accumulate
    forever). Kept: the small caches managed by their own logic, and every
    subtitle belonging to the video Kodi currently has loaded - playing or
    paused - however old it is, so a long pause can't delete a subtitle
    that's still in use."""
    keep = {os.path.basename(ROWS_FILE), os.path.basename(CATALOG_FILE), os.path.basename(OWNERS_FILE)}
    owners = _read_owners()
    video = current_video()
    try:
        now = time.time()
        for name in os.listdir(TEMP_DIR):
            if name in keep or not name.startswith('nyasub_'):
                continue
            if video and owners.get(name) == video:
                continue
            path = os.path.join(TEMP_DIR, name)
            try:
                age = now - os.path.getmtime(path)
            except OSError:
                continue
            if age < TEMP_MAX_AGE_SECONDS:
                continue
            try:
                if os.path.isdir(path):
                    shutil.rmtree(path, ignore_errors=True)
                else:
                    os.remove(path)
            except OSError as e:
                log("cleanup: couldn't remove {0}: {1}".format(path, e))
        existing = set(os.listdir(TEMP_DIR))
        still_there = dict((k, v) for k, v in owners.items() if k in existing)
        if still_there != owners:
            _write_owners(still_there)
    except Exception as e:
        log("cleanup_temp_dir failed: {0}".format(e))


# ---------------- title/query cleanup (same logic as Hiyori/WoSir/Edna) ----------------

def clean_release_title(name):
    if not name:
        return name
    name = re.sub(r'\.\w+$', '', name)
    name = re.sub(r'\[[^\]]*\]', ' ', name)
    name = re.sub(r'\([^)]*\)', ' ', name)
    name = re.sub(r'[._]', ' ', name)

    lower = name.lower()
    cut_at = None
    m = re.search(r's\d{1,2}e\d{1,2}', lower)
    if m:
        cut_at = m.start()
    keywords = [
        "2160p", "1080p", "720p", "480p", "4k",
        "blu-ray", "bluray", "bdrip", "webrip", "web-dl", "web dl",
        "hdtv", "dvdrip", "hdrip",
        "x264", "x265", "h264", "h265", "hevc", "avc",
        "dual audio", "dual-audio", "multi audio", "multi-audio",
        "aac", "flac", "dts", "opus",
    ]
    for kw in keywords:
        idx = lower.find(kw)
        if idx != -1 and (cut_at is None or idx < cut_at):
            cut_at = idx
    if cut_at is not None:
        name = name[:cut_at]

    name = re.sub(r'\s-\s*\d+.*$', '', name)
    name = re.sub(r'[-–—]+\s*$', '', name)
    name = re.sub(r'\s+', ' ', name).strip()
    return name


def extract_season_episode(text):
    if not text:
        return text, None, None
    m = re.search(r'[sS](\d{1,2})[eE](\d{1,3})', text)
    if not m:
        return text, None, None
    season = int(m.group(1))
    episode = int(m.group(2))
    cleaned = (text[:m.start()] + text[m.end():]).strip()
    cleaned = clean_release_title(cleaned) or cleaned
    return cleaned, season, episode


def pick_best_match(query, titles):
    if not titles:
        return None
    titles_lower = [t.lower() for t in titles]
    close = difflib.get_close_matches(query.lower(), titles_lower, n=1, cutoff=0.0)
    if close:
        return titles[titles_lower.index(close[0])]
    return titles[0]


def get_allowed_languages(params):
    raw = params.get('languages', [''])[0]
    if not raw:
        return None
    return set(unquote(n) for n in raw.split(','))


# ---------------- site access ----------------

def build_catalog(session):
    """Returns {title: [{"label": ..., "href": ...}, ...]} - one entry
    per season/movie/OVA link found under that title's <h2> heading."""
    try:
        resp = session.get(CATALOG_URL, headers=HEADERS, timeout=15)
        html_text = resp.text
    except Exception as e:
        log("catalog page fetch failed: {0}".format(e))
        return {}

    headings = list(re.finditer(r'<h2[^>]*>(.*?)</h2>', html_text, re.DOTALL))
    catalog = {}
    for i, h in enumerate(headings):
        title = html_mod.unescape(re.sub(r'<[^>]+>', '', h.group(1))).strip()
        if not title:
            continue
        section_start = h.end()
        section_end = headings[i + 1].start() if i + 1 < len(headings) else len(html_text)
        section = html_text[section_start:section_end]
        entries = []
        for m in re.finditer(
            r'<a\s+[^>]*href="(https://nyasub\.cz/hotove-preklady/[a-z0-9\-]+/)"[^>]*>\s*([^<]*?)\s*</a>',
            section
        ):
            href, label = m.group(1), html_mod.unescape(m.group(2)).strip()
            if href and label:
                entries.append({"label": label, "href": href})
        if entries:
            catalog[title] = entries
    save_json(CATALOG_FILE, {"ts": time.time(), "catalog": catalog})
    log("catalog: {0} title(s) built from {1}".format(len(catalog), CATALOG_URL))
    return catalog


def get_catalog(session):
    cached = load_json(CATALOG_FILE)
    if cached and (time.time() - cached.get("ts", 0)) < CATALOG_TTL and cached.get("catalog"):
        log("using cached catalog ({0} title(s), age {1:.0f}s)".format(
            len(cached["catalog"]), time.time() - cached["ts"]))
        return cached["catalog"]
    log("catalog cache missing/stale - rebuilding")
    return build_catalog(session)


def pick_season_entry(entries, season):
    """Picks the season/movie entry to use. Entries whose label is a
    recognizable 'N.serie' are matched by season number; anything else
    (a film/OVA name, 'cast prvni', ...) can only be matched by position.
    Defaults to the first entry when nothing more specific is known."""
    if season is not None:
        for e in entries:
            m = SEASON_LABEL_RE.match(e['label'])
            if m and int(m.group(1)) == season:
                return e
        if 1 <= season <= len(entries):
            return entries[season - 1]
        log("season {0} requested but not found among {1} entrie(s), using the first".format(
            season, len(entries)))
    return entries[0]


def fetch_episode_links(session, href):
    """Returns [download_url, ...] in on-screen episode order (episode
    number = position + 1) - see the module docstring for why this is
    keyed by order rather than parsed episode numbers."""
    try:
        resp = session.get(href, headers=HEADERS, timeout=15)
        html_text = resp.text
    except Exception as e:
        log("episode page fetch failed for {0}: {1}".format(href, e))
        return []
    links = []
    # The "Titulky" text sits inside nested <span>/<i> icon markup, not
    # directly against the <a> tags - confirmed live via the real page
    # source (view-source, not a rendered DOM read), so this matches
    # loosely across those inner tags rather than assuming plain text
    # right after '>'.
    for m in re.finditer(
        r'<a\s+[^>]*href="([^"]*\?wpdmdl=\d+[^"]*)"[^>]*>[\s\S]*?Titulky[\s\S]*?</a>',
        html_text, re.IGNORECASE
    ):
        links.append(html_mod.unescape(m.group(1)))
    return links


def guess_extension(content_disposition, body_sample):
    m = re.search(r'filename\*?=[^\'"]*[\'"]?([^\'";\r\n]+)', content_disposition or "")
    if m:
        ext_m = re.search(r'\.([A-Za-z]+)$', m.group(1))
        if ext_m:
            return "." + ext_m.group(1)
    try:
        sample_text = body_sample.decode('utf-8', 'ignore')
    except Exception:
        sample_text = ""
    stripped = sample_text.strip()
    if stripped.startswith("[Script Info]"):
        return ".ass"
    if re.match(r'^\d+\s*$', stripped.splitlines()[0] if stripped.splitlines() else ""):
        return ".srt"
    return ".srt"


# ---------------- Kodi-facing actions ----------------

def append_subtitle(lang_name, flag_code, label2, url_params):
    listitem = xbmcgui.ListItem(label=lang_name, label2=label2)
    if flag_code:
        listitem.setArt({"thumb": flag_code})
    listitem.setProperty("sync", "false")
    listitem.setProperty("hearing_imp", "false")
    url = "plugin://{0}/?{1}".format(
        ADDON_ID,
        "&".join("{0}={1}".format(k, requests.utils.quote(str(v))) for k, v in url_params.items())
    )
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=listitem, isFolder=False)


def handle_search(params, is_manual):
    season = episode = None
    if is_manual:
        query_raw = params.get('searchstring', [''])[0]
        query, season, episode = extract_season_episode(query_raw)
        if not query:
            query = clean_release_title(query_raw)
    else:
        tvshow = xbmc.getInfoLabel("VideoPlayer.TVshowtitle")
        title = tvshow or xbmc.getInfoLabel("VideoPlayer.OriginalTitle") or xbmc.getInfoLabel("VideoPlayer.Title")
        season_label = xbmc.getInfoLabel("VideoPlayer.Season")
        episode_label = xbmc.getInfoLabel("VideoPlayer.Episode")
        if season_label.isdigit():
            season = int(season_label)
        if episode_label.isdigit():
            episode = int(episode_label)

        if title:
            query = clean_release_title(title)
        else:
            try:
                filename = os.path.basename(unquote(xbmc.Player().getPlayingFile()))
            except Exception:
                filename = ""
            query, s2, e2 = extract_season_episode(filename)
            query = clean_release_title(query)
            if season is None:
                season = s2
            if episode is None:
                episode = e2

    query = (query or "").strip()
    if not query:
        log("no usable search query, aborting")
        return

    log("query='{0}' season={1} episode={2} manual={3}".format(query, season, episode, is_manual))

    session = requests.Session()
    catalog = get_catalog(session)
    log("{0} title(s) in catalog".format(len(catalog)))
    if not catalog:
        return

    titles = list(catalog.keys())
    best_title = pick_best_match(query, titles)
    entries = catalog[best_title]
    log("picked title: '{0}' ({1} season/movie entrie(s))".format(best_title, len(entries)))

    entry = pick_season_entry(entries, season)
    log("using entry label='{0}' href={1}".format(entry['label'], entry['href']))

    links = fetch_episode_links(session, entry['href'])
    log("{0} episode download link(s) found".format(len(links)))
    if not links:
        return

    rows = [{"ep": i + 1, "url": url} for i, url in enumerate(links)]

    if episode is not None:
        matching = [r for r in rows if r['ep'] == episode]
        if matching:
            rows = matching
        else:
            log("no row matched episode {0}, showing full list instead".format(episode))

    allowed_langs = get_allowed_languages(params)
    if allowed_langs and LANG_NAME not in allowed_langs:
        log("Czech filtered out by allowed_langs, nothing to show")
        return

    saved = {}
    shown = 0
    for i, row in enumerate(rows):
        rid = str(i)
        saved[rid] = row
        label2 = "Episode {0}".format(row['ep'])
        append_subtitle(LANG_NAME, LANG_FLAG, label2, {"action": "download", "rid": rid})
        shown += 1

    save_json(ROWS_FILE, saved)
    log("listed {0} subtitle(s) for '{1}'".format(shown, best_title))


def fetch_download(url):
    """GET with one retry - the site's download endpoint has been observed
    to occasionally report a non-200 status even on requests that server-
    side actually succeeded (see module docstring), so a first failure is
    retried once before giving up."""
    last_exc = None
    for attempt in range(2):
        try:
            resp = requests.get(url, headers=HEADERS, timeout=20)
            if resp.content and resp.content.lstrip()[:1] != b'<':
                return resp
            log("attempt {0}: status={1} bytes={2} (looks empty/HTML)".format(
                attempt + 1, resp.status_code, len(resp.content or b"")))
        except Exception as e:
            last_exc = e
            log("attempt {0} failed: {1}".format(attempt + 1, e))
        if attempt == 0:
            time.sleep(1.5)
    if last_exc:
        raise last_exc
    return resp


def handle_download(params):
    rid = params.get('rid', [None])[0]
    if rid is None:
        notify("Nothing to download.")
        return
    rows = load_json(ROWS_FILE) or {}
    row = rows.get(rid)
    if not row:
        notify("Subtitle info expired - please search again.")
        return

    try:
        resp = fetch_download(row['url'])
        content = resp.content
        content_disposition = resp.headers.get('Content-Disposition', '')
    except Exception as e:
        log("download failed: {0}".format(e))
        notify("Download failed (see debug log).")
        return

    if not content or content.lstrip()[:1] == b'<':
        notify("Download failed - unexpected response (see debug log). Try again in a moment.")
        log("download got empty/HTML body for episode {0}".format(row.get('ep')))
        return

    if len(content) > MAX_DOWNLOAD_BYTES:
        notify("Download refused - file is larger than expected (see debug log).")
        log("download refused: {0} bytes exceeds MAX_DOWNLOAD_BYTES {1}".format(
            len(content), MAX_DOWNLOAD_BYTES))
        return

    safe_name = "ep{0}".format(row.get('ep', '0'))
    is_zip = content[:2] == b'PK'

    if is_zip:
        zip_path = os.path.join(TEMP_DIR, "nyasub_{0}_{1}.zip".format(safe_name, int(time.time())))
        try:
            with open(zip_path, 'wb') as f:
                f.write(content)
        except Exception as e:
            log("failed to write zip file: {0}".format(e))
            notify("Downloaded but couldn't save the file (see debug log).")
            return

        extract_dir = os.path.join(TEMP_DIR, "nyasub_{0}_{1}".format(safe_name, int(time.time())))
        try:
            with zipfile.ZipFile(zip_path) as zf:
                extracted_size = sum(info.file_size for info in zf.infolist())
                if extracted_size > MAX_EXTRACTED_BYTES:
                    notify("Download refused - archive is larger than expected when extracted (see debug log).")
                    log("refusing to extract {0}: extracted size {1} exceeds MAX_EXTRACTED_BYTES {2}".format(
                        zip_path, extracted_size, MAX_EXTRACTED_BYTES))
                    return
                zf.extractall(extract_dir)
        except Exception as e:
            log("zip extract failed: {0}".format(e))
            notify("Downloaded a zip but couldn't extract it (see debug log).")
            return

        sub_file = None
        for root, _dirs, files in os.walk(extract_dir):
            for fn in files:
                if fn.lower().endswith(('.srt', '.ass', '.sub')):
                    sub_file = os.path.join(root, fn)
                    break
            if sub_file:
                break
        if not sub_file:
            notify("Downloaded and extracted, but no .srt/.ass file found inside.")
            log("no subtitle file found after extracting {0}".format(zip_path))
            return
        filepath = sub_file
    else:
        ext = guess_extension(content_disposition, content[:200])
        filename = "nyasub_{0}_{1}{2}".format(safe_name, int(time.time()), ext)
        filepath = os.path.join(TEMP_DIR, filename)
        try:
            with open(filepath, 'wb') as f:
                f.write(content)
        except Exception as e:
            log("failed to write subtitle file: {0}".format(e))
            notify("Downloaded but couldn't save the file (see debug log).")
            return

    remember_owner(filepath)

    log("saved subtitle to {0}".format(filepath))
    listitem = xbmcgui.ListItem(label=os.path.basename(filepath))
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=filepath, listitem=listitem, isFolder=False)


def run():
    try:
        cleanup_temp_dir()
        params = get_params()
        action = params.get('action', [''])[0]
        log("action={0} params={1}".format(action, params))
        if action == 'search':
            handle_search(params, is_manual=False)
        elif action == 'manualsearch':
            handle_search(params, is_manual=True)
        elif action == 'download':
            handle_download(params)
        else:
            log("unknown/missing action, nothing to do")
    except Exception as e:
        log("unhandled exception: {0}\n{1}".format(e, traceback.format_exc()))
    finally:
        xbmcplugin.endOfDirectory(HANDLE)


if __name__ == '__main__':
    run()
