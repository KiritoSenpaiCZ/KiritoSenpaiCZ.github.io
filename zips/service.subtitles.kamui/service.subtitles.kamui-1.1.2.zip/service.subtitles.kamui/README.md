# Kamui-Subs Subtitles - Kodi Subtitle Addon

Kodi subtitle service addon for kamui-subs.cz — Czech anime subtitles.

Compatible with Kodi 19, 20, and 21.

## Current Version
service.subtitles.kamui - 1.1.2

## Installation Instructions
Recommended: install through the [Highflight Subtitles Repository](https://github.com/KiritoSenpaiCZ/KiritoSenpaiCZ.github.io), which also handles updates.

Manual install:
1. Download `service.subtitles.kamui-1.1.2.zip` from this repo (or build it from source)
2. In Kodi: **Add-ons > Install from zip file**, select the zip

## Setup Instructions
1. In Kodi, open this addon's settings
2. Enter your kamui-subs.cz username and password
3. Enter the site's zip password (subtitle downloads are password-protected zips — check kamui-subs.cz if you don't know it)

## How it works
- Searches kamui-subs.cz using the show title from Kodi's video metadata (or a manual search)
- Each season has its own page on the site; downloads are extracted automatically from their password-protected zip
- Whole-series bulk download isn't supported (not needed for single-episode playback)
- Logs in fresh on every search/download — no session is cached
- Downloaded files are validated before use (rejects HTML error pages and oversized responses/archives) and old temp files are swept automatically

## Issues
Please open an issue in this repo with a description of the problem and, if possible, a Kodi debug log (Settings > System > Logging > Enable debug logging, then grep `kodi.log` for `[Kamui]`).

## FAQ
**Q: I get a prompt about a zip password.**
**A:** kamui-subs.cz protects its subtitle downloads with a site-wide zip password — enter it in this addon's settings (check the kamui-subs.cz site if you don't know it).
