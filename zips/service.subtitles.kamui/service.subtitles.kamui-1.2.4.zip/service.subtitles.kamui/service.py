# -*- coding: utf-8 -*-
"""
Kamui-Subs.cz Subtitles - Kodi subtitle service addon.

Site notes:
  - WordPress + Elementor + Ultimate Member (login) + WP Download Manager
    (files) - all off-the-shelf plugins, no custom anti-bot layer.
  - Each show/season is its OWN page (e.g. /tensei-shitara-slime-datta-ken-s4/,
    /tensei-shitara-slime-datta-ken-s3/). Season 1 (or a show with only
    one season/a movie) has no "S<n>" suffix in the title at all.
  - Every page's episode buttons are simple links:
    <a href="https://kamui-subs.cz/download/<id>/">N. Díl</a>
    plus one "Celá série" (whole-season zip) link, which is deliberately
    skipped (Kodi wants one episode's subtitle, not a bulk archive).
  - The episode/download links are only present in the page HTML while
    logged in - logged out, the whole button block is missing.
  - Every /download/<id>/ response is a .zip (standard WP Download Manager
    file-serving headers), so the addon expects a zip and extracts it,
    with a raw-file fallback in case an older upload isn't zipped.
  - Subtitles are Czech only - no per-episode language flags.
  - Login is Ultimate Member's default form: GET /log-in/ to scrape a
    fresh _wpnonce and form_id from the (dynamically-numbered) login
    form's hidden fields, then POST username-<form_id>/
    user_password-<form_id> plus those hidden fields back to /log-in/
    itself. Success is checked via a "wordpress_logged_in_*" cookie
    landing in the session after the POST.
  - WordPress's own site search (GET /?s=<query>) finds show pages
    (article.type-page) alongside per-episode "download item" posts
    (article.type-lana_download), which are filtered out.
  - Logs in fresh on every search and download (no session caching).

Debugging: enable Kodi's debug log (Settings -> System -> Logging),
reproduce, then look for "[Kamui]" lines in kodi.log.
"""

import difflib
import html as html_mod
import json
import os
import re
import shutil
import sys
import time
import traceback
import zipfile
from urllib.parse import parse_qs, unquote

import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')

PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
TEMP_DIR = xbmcvfs.translatePath(os.path.join(PROFILE, 'temp', ''))
if not xbmcvfs.exists(TEMP_DIR):
    xbmcvfs.mkdirs(TEMP_DIR)
ROWS_FILE = os.path.join(TEMP_DIR, 'kamui_rows.json')
OWNERS_FILE = os.path.join(TEMP_DIR, 'kamui_owners.json')

HANDLE = int(sys.argv[1])

BASE_URL = "https://kamui-subs.cz"
LOGIN_URL = BASE_URL + "/log-in/"
HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                  "(KHTML, like Gecko) Chrome/124.0 Safari/537.36"
}

LANG_NAME = "Czech"
LANG_FLAG = "cs"

# Anything left behind in TEMP_DIR older than this gets swept on the next
# run - a search+download round trip finishes in well under a minute, so
# anything still there an hour later is leftover, not in-use.
TEMP_MAX_AGE_SECONDS = 3600
# temp-folder entries this addon creates start with TEMP_FILE_PREFIX;
# KEEP_FILES are never swept
TEMP_FILE_PREFIX = 'kamui_'
KEEP_FILES = {os.path.basename(ROWS_FILE), os.path.basename(OWNERS_FILE)}

# Refuse an implausibly large download or an implausibly large *extracted*
# zip - subtitle files/packs are small, so either cap being hit means
# something's wrong (a huge unexpected response, or a zip bomb).
MAX_DOWNLOAD_BYTES = 20 * 1024 * 1024
MAX_EXTRACTED_BYTES = 200 * 1024 * 1024

# Every downloaded zip on this site is password-protected with a fixed,
# site-wide password (same for every user/download). It is deliberately
# NOT hardcoded here: this addon's source lives
# in a public repo, and baking a password into public source code is bad
# practice even when the password itself is not a secret. The user enters
# it once in this addon's settings instead (see zip_password below).


# >>> shared block "kodi_lang" - edit dev/shared/kodi_lang.py in KiritoSenpaiCZ.github.io, then run dev/sync.py
# The addon's messages are in Czech when Kodi's language is Czech or Slovak,
# English otherwise. L("english", "czech", *args) picks one and fills in
# {0}-style placeholders like str.format.
try:
    _UI_LANG = xbmc.getLanguage(xbmc.ISO_639_1)
except Exception:
    _UI_LANG = ''


def L(en, cs, *args):
    text = cs if _UI_LANG in ('cs', 'sk') else en
    return text.format(*args) if args else text
# <<< shared block "kodi_lang"


# ---------------- small helpers ----------------

def log(msg):
    xbmc.log("[Kamui] {0}".format(msg), level=xbmc.LOGDEBUG)


def notify(msg):
    xbmcgui.Dialog().notification(ADDON_NAME, msg, xbmcgui.NOTIFICATION_INFO, 4000)


def get_params():
    raw = sys.argv[2] if len(sys.argv) > 2 else ""
    return parse_qs(raw.lstrip('?'))


def save_rows(rows_dict):
    try:
        with open(ROWS_FILE, 'w', encoding='utf-8') as f:
            json.dump(rows_dict, f)
    except Exception as e:
        log("failed to save rows cache: {0}".format(e))


def load_rows():
    try:
        with open(ROWS_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {}


# >>> shared block "kodi_temp" - edit dev/shared/kodi_temp.py in KiritoSenpaiCZ.github.io, then run dev/sync.py
def current_video():
    """Path of the video Kodi has loaded - playing OR paused - else None.
    (Player.Playing alone isn't enough: it's false while paused.)"""
    try:
        if xbmc.getCondVisibility('Player.HasVideo') or xbmc.getCondVisibility('Player.Paused'):
            return xbmc.getInfoLabel('Player.Filenameandpath') or None
    except Exception:
        pass
    return None


def _read_owners():
    try:
        with open(OWNERS_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _write_owners(owners):
    try:
        with open(OWNERS_FILE, 'w', encoding='utf-8') as f:
            json.dump(owners, f)
    except Exception as e:
        log("couldn't save {0}: {1}".format(OWNERS_FILE, e))


def remember_owner(path):
    """Record which video a delivered subtitle belongs to, so
    cleanup_temp_dir() never deletes it while that video is still loaded
    (e.g. paused for more than an hour)."""
    video = current_video()
    if not video:
        return
    try:
        top = os.path.relpath(path, TEMP_DIR).split(os.sep)[0]
    except ValueError:
        return
    if not top or top.startswith('..'):
        return
    owners = _read_owners()
    owners[top] = video
    _write_owners(owners)


def cleanup_temp_dir():
    """Sweep old downloads out of TEMP_DIR. Kept: KEEP_FILES (small caches
    managed by their own logic), and every subtitle belonging to the video
    Kodi currently has loaded - playing or paused - however old it is, so a
    long pause can't delete a subtitle that's still in use."""
    keep = KEEP_FILES
    owners = _read_owners()
    video = current_video()
    try:
        now = time.time()
        for name in os.listdir(TEMP_DIR):
            if name in keep or not name.startswith(TEMP_FILE_PREFIX):
                continue
            if video and owners.get(name) == video:
                continue
            path = os.path.join(TEMP_DIR, name)
            try:
                age = now - os.path.getmtime(path)
            except OSError:
                continue
            if age < TEMP_MAX_AGE_SECONDS:
                continue
            try:
                if os.path.isdir(path):
                    shutil.rmtree(path, ignore_errors=True)
                else:
                    os.remove(path)
            except OSError as e:
                log("cleanup: couldn't remove {0}: {1}".format(path, e))
        existing = set(os.listdir(TEMP_DIR))
        still_there = dict((k, v) for k, v in owners.items() if k in existing)
        if still_there != owners:
            _write_owners(still_there)
    except Exception as e:
        log("cleanup_temp_dir failed: {0}".format(e))
# <<< shared block "kodi_temp"


# >>> shared block "kodi_titles" - edit dev/shared/kodi_titles.py in KiritoSenpaiCZ.github.io, then run dev/sync.py
def split_season_title(title):
    """Strips a season / cour ending from a show title and returns
    (base title, season or None). Players and anime addons often pass the
    full season name, e.g. "Tensei Shitara Slime Datta Ken 4th Season
    Part 1 & 2"; the site searches need every word to match, so they would
    find nothing. "Part N" (a cour split) is dropped without a season."""
    if not title:
        return title, None
    part = r'[\s:\-–]*\bpart\s*\d+(?:\s*(?:&|and|\+)\s*\d+)?\s*$'
    base = re.sub(part, '', title.strip(), flags=re.I)
    season = None
    for pattern in (r'\b(\d{1,2})(?:st|nd|rd|th)\s+season$',
                    r'\bseason\s*(\d{1,2})$',
                    r'\bs(\d{1,2})$'):
        m = re.search(r'[\s:\-–]*' + pattern, base, re.I)
        if m:
            season = int(m.group(1))
            base = base[:m.start()]
            break
    base = re.sub(part, '', base, flags=re.I)
    base = re.sub(r'[\s:\-–]+$', '', base).strip()
    return (base or title), season
# <<< shared block "kodi_titles"


# ---------------- title/query cleanup ----------------

def clean_release_title(name):
    if not name:
        return name
    name = re.sub(r'\.\w+$', '', name)          # extension
    name = re.sub(r'\[[^\]]*\]', ' ', name)      # [tags]
    name = re.sub(r'\([^)]*\)', ' ', name)       # (tags)
    name = re.sub(r'[._]', ' ', name)            # dots/underscores -> spaces

    lower = name.lower()
    cut_at = None
    m = re.search(r's\d{1,2}e\d{1,2}', lower)
    if m:
        cut_at = m.start()
    keywords = [
        "2160p", "1080p", "720p", "480p", "4k",
        "blu-ray", "bluray", "bdrip", "webrip", "web-dl", "web dl",
        "hdtv", "dvdrip", "hdrip",
        "x264", "x265", "h264", "h265", "hevc", "avc",
        "dual audio", "dual-audio", "multi audio", "multi-audio",
        "aac", "flac", "dts", "opus",
    ]
    for kw in keywords:
        idx = lower.find(kw)
        if idx != -1 and (cut_at is None or idx < cut_at):
            cut_at = idx
    if cut_at is not None:
        name = name[:cut_at]

    name = re.sub(r'\s-\s*\d+.*$', '', name)     # trailing "- 05..." marker
    name = re.sub(r'[-–—]+\s*$', '', name)  # leftover trailing dash
    name = re.sub(r'\s+', ' ', name).strip()
    return name


def extract_season_episode(text):
    """Pull a leading/embedded 'S01E02' style marker out of a string
    (mainly for Kodi's manual-search box), returning (cleaned_text,
    season, episode)."""
    if not text:
        return text, None, None
    m = re.search(r'[sS](\d{1,2})[eE](\d{1,3})', text)
    if not m:
        return text, None, None
    season = int(m.group(1))
    episode = int(m.group(2))
    cleaned = (text[:m.start()] + text[m.end():]).strip()
    cleaned = clean_release_title(cleaned) or cleaned
    return cleaned, season, episode



def pick_best_match(target_title, shows):
    """Case-insensitive closest-title match against the season-qualified
    target (e.g. 'Tensei Shitara Slime Datta Ken S4'), since each season
    is its own separate search result here rather than one show entry."""
    if not shows:
        return None
    titles_lower = [s['title'].lower() for s in shows]
    close = difflib.get_close_matches(target_title.lower(), titles_lower, n=1, cutoff=0.0)
    if close:
        return shows[titles_lower.index(close[0])]
    return shows[0]


def get_allowed_languages(params):
    raw = params.get('languages', [''])[0]
    if not raw:
        return None
    return set(unquote(n) for n in raw.split(','))


# ---------------- site access ----------------

def login(session, username, password):
    """Fresh login on a brand-new requests.Session() every time. Ultimate
    Member's login form names its username/password fields dynamically
    as username-<form_id>/user_password-<form_id>, and requires a fresh
    _wpnonce scraped from the just-loaded form - both scraped here rather
    than hardcoded in case the form_id ever changes."""
    # The site's page cache serves an old copy of the login page whose
    # _wpnonce expires after about a day; any query parameter skips the cache.
    try:
        resp = session.get(LOGIN_URL, params={"nocache": int(time.time())},
                           headers=HEADERS, timeout=15)
        login_page = resp.text
    except Exception as e:
        log("login page fetch failed: {0}".format(e))
        return False

    form_id = None
    m = re.search(r'name="form_id"\s+[^>]*value="(\d+)"', login_page)
    if not m:
        m = re.search(r'id="form_id_(\d+)"', login_page)
    if m:
        form_id = m.group(1)
    if not form_id:
        log("login: form_id not found on login page")
        return False

    nonce = None
    m = re.search(r'name="_wpnonce"\s+[^>]*value="([0-9a-f]+)"', login_page)
    if m:
        nonce = m.group(1)
    if not nonce:
        log("login: _wpnonce not found on login page")
        return False

    referer = None
    m = re.search(r'name="_wp_http_referer"\s+[^>]*value="([^"]*)"', login_page)
    if m:
        referer = html_mod.unescape(m.group(1))

    data = {
        "username-{0}".format(form_id): username,
        "user_password-{0}".format(form_id): password,
        "form_id": form_id,
        "um_request": "",
        "redirect_to": BASE_URL + "/",
        "_wpnonce": nonce,
        "_wp_http_referer": referer or "/log-in/",
    }
    headers = dict(HEADERS)
    headers["Referer"] = LOGIN_URL

    try:
        resp = session.post(LOGIN_URL, data=data, headers=headers, timeout=15)
    except Exception as e:
        log("login post failed: {0}".format(e))
        return False

    ok = any(c.name.startswith("wordpress_logged_in_") for c in session.cookies)
    log("login {0} (form_id={1})".format("succeeded" if ok else "failed", form_id))
    if not ok:
        log_login_failure(resp, session, username, password)
    return ok


def describe_value(value):
    """Yes/no facts about a saved setting, never the value itself."""
    return "empty={0} edge_spaces={1} non_ascii={2} control_chars={3}".format(
        not value,
        value != value.strip(),
        any(ord(ch) > 127 for ch in value),
        any(ord(ch) < 32 for ch in value),
    )


def log_login_failure(resp, session, username, password):
    """Logs what the site answered to a failed login, so the cause shows
    in kodi.log. Credentials are only described, never written out."""
    hops = " -> ".join(str(r.status_code) for r in resp.history + [resp])
    log("login reply: status {0}, final url {1}".format(hops, resp.url))
    log("login cookies: {0}".format(sorted(c.name for c in session.cookies)))
    messages = []
    for m in re.finditer(
        r'<(p|div|span)[^>]*class="[^"]*(?:um-notice|um-field-error|login_error|error)[^"]*"[^>]*>(.*?)</\1>',
        resp.text, re.DOTALL | re.I
    ):
        text = re.sub(r'<[^>]+>', ' ', m.group(2))
        text = re.sub(r'\s+', ' ', html_mod.unescape(text)).strip()
        if text and text not in messages:
            messages.append(text[:200])
    log("login site messages: {0}".format(messages or "none"))
    log("login username: {0}".format(describe_value(username)))
    log("login password: {0}".format(describe_value(password)))


def parse_search_results(html_text):
    """Returns [{title, url}] for real show/season pages only - WordPress's
    own search also matches individual per-episode 'download item' posts
    (article.type-lana_download) which carry no useful content of their
    own and are skipped here."""
    results = []
    for m in re.finditer(
        r'<article[^>]*\bid="post-\d+"[^>]*\bclass="[^"]*\btype-page\b[^"]*"[^>]*>(.*?)</article>',
        html_text, re.DOTALL
    ):
        block = m.group(1)
        link_m = re.search(r'<a\s+href="([^"]+)"[^>]*>\s*([^<]+?)\s*</a>', block)
        if link_m:
            results.append({
                "url": link_m.group(1),
                "title": html_mod.unescape(link_m.group(2)).strip(),
            })
    return results


def search_site(session, query):
    try:
        resp = session.get(BASE_URL + "/", params={"s": query}, headers=HEADERS, timeout=15)
        html_text = resp.text
    except Exception as e:
        log("search request failed: {0}".format(e))
        return []
    return parse_search_results(html_text)


def fetch_episode_links(session, show_url):
    """Returns [{ep, href}] - one entry per numbered episode button on the
    show/season's page ('Celá série' whole-season zip is skipped)."""
    try:
        resp = session.get(show_url, headers=HEADERS, timeout=15)
        html_text = resp.text
    except Exception as e:
        log("show page request failed: {0}".format(e))
        return []
    return parse_episode_links(html_text)


def parse_episode_links(html_text):
    """Each button is an Elementor widget - the href sits on the <a> tag,
    but the visible label is two <span> levels deeper
    (elementor-button-content-wrapper > elementor-button-text), not direct
    text on the <a> itself."""
    rows = []
    for m in re.finditer(
        r'<a\b[^>]*\bhref="(https://kamui-subs\.cz/download/\d+/)"[^>]*>(.*?)</a>',
        html_text, re.DOTALL
    ):
        href, inner = m.group(1), m.group(2)
        text_m = re.search(r'elementor-button-text">\s*([^<]+?)\s*</span>', inner)
        if not text_m:
            continue
        text = html_mod.unescape(text_m.group(1)).strip()
        ep_m = re.match(r'(\d+)\s*\.\s*D[ií]l', text, re.IGNORECASE)
        if not ep_m:
            continue  # skips "Celá série" and anything else non-numbered
        rows.append({"ep": int(ep_m.group(1)), "href": href, "label": text})
    log("parsed {0} numbered episode link(s)".format(len(rows)))
    return rows


SUBTITLE_EXTS = ('.srt', '.ass', '.ssa', '.sub', '.vtt')


def _find_subtitle_file(root_dir):
    for root, _dirs, files in os.walk(root_dir):
        for fn in files:
            if fn.lower().endswith(SUBTITLE_EXTS):
                return os.path.join(root, fn)
    return None


class ZipTooLargeError(Exception):
    """Raised when a zip's uncompressed contents exceed MAX_EXTRACTED_BYTES -
    a zip-bomb guard, checked before extraction rather than after."""
    pass


def _check_extracted_size(zf):
    extracted_size = sum(info.file_size for info in zf.infolist())
    if extracted_size > MAX_EXTRACTED_BYTES:
        raise ZipTooLargeError("extracted size {0} exceeds MAX_EXTRACTED_BYTES {1}".format(
            extracted_size, MAX_EXTRACTED_BYTES))


def _extract_zip(zip_path, extract_dir, zip_password=None):
    """Extract a zip, retrying with the addon-settings zip password (if one
    is configured) if the first attempt fails because the archive is
    encrypted (zipfile raises RuntimeError for both "Bad password" and
    "password required"). Raises RuntimeError if a password was needed but
    none is configured, or the configured one is wrong - the caller uses
    that to prompt the user to check the setting. Raises ZipTooLargeError
    (a zip-bomb guard) if the archive's uncompressed contents would exceed
    MAX_EXTRACTED_BYTES, checked before extraction either way."""
    try:
        with zipfile.ZipFile(zip_path) as zf:
            _check_extracted_size(zf)
            zf.extractall(extract_dir)
        return
    except RuntimeError as e:
        if not zip_password:
            log("extract without password failed ({0}) and no zip password is set".format(e))
            raise
        log("extract without password failed ({0}), retrying with the configured zip password".format(e))
    with zipfile.ZipFile(zip_path) as zf:
        _check_extracted_size(zf)
        zf.extractall(extract_dir, pwd=zip_password.encode('utf-8'))


def _find_nested_zip(root_dir):
    for root, _dirs, files in os.walk(root_dir):
        for fn in files:
            if fn.lower().endswith('.zip'):
                return os.path.join(root, fn)
    return None


def guess_extension(content_disposition, body_sample):
    m = re.search(r'filename\*?=[^\'"]*[\'"]?([^\'";\r\n]+)', content_disposition or "")
    if m:
        ext_m = re.search(r'\.([A-Za-z]+)$', m.group(1))
        if ext_m:
            return "." + ext_m.group(1)
    try:
        sample_text = body_sample.decode('utf-8', 'ignore')
    except Exception:
        sample_text = ""
    if sample_text.strip().startswith("[Script Info]"):
        return ".ass"
    return ".srt"


# ---------------- Kodi-facing actions ----------------

def append_subtitle(label2, url_params):
    listitem = xbmcgui.ListItem(label=LANG_NAME, label2=label2)
    listitem.setArt({"thumb": LANG_FLAG})
    listitem.setProperty("sync", "false")
    listitem.setProperty("hearing_imp", "false")
    url = "plugin://{0}/?{1}".format(
        ADDON_ID,
        "&".join("{0}={1}".format(k, requests.utils.quote(str(v))) for k, v in url_params.items())
    )
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=listitem, isFolder=False)


def handle_search(params, is_manual):
    username = ADDON.getSetting('username')
    password = ADDON.getSetting('password')
    if not username or not password:
        notify(L('Set your kamui-subs.cz username/password in the addon settings.', 'Nastavte své jméno a heslo ke kamui-subs.cz v nastavení doplňku.'))
        ADDON.openSettings()
        return

    season = episode = None
    if is_manual:
        query_raw = params.get('searchstring', [''])[0]
        query, season, episode = extract_season_episode(query_raw)
        if not query:
            query = clean_release_title(query_raw)
    else:
        tvshow = xbmc.getInfoLabel("VideoPlayer.TVshowtitle")
        title = tvshow or xbmc.getInfoLabel("VideoPlayer.OriginalTitle") or xbmc.getInfoLabel("VideoPlayer.Title")
        season_label = xbmc.getInfoLabel("VideoPlayer.Season")
        episode_label = xbmc.getInfoLabel("VideoPlayer.Episode")
        if season_label.isdigit():
            season = int(season_label)
        if episode_label.isdigit():
            episode = int(episode_label)

        if title:
            query = clean_release_title(title)
        else:
            try:
                filename = os.path.basename(unquote(xbmc.Player().getPlayingFile()))
            except Exception:
                filename = ""
            query, s2, e2 = extract_season_episode(filename)
            query = clean_release_title(query)
            if season is None:
                season = s2
            if episode is None:
                episode = e2

    query, title_season = split_season_title((query or "").strip())
    if season is None:
        season = title_season
    if not query:
        log("no usable search query, aborting")
        return

    log("query='{0}' season={1} episode={2} manual={3}".format(query, season, episode, is_manual))

    session = requests.Session()
    if not login(session, username, password):
        notify(L('Kamui-subs.cz login failed - check username/password in addon settings.', 'Přihlášení ke kamui-subs.cz selhalo - zkontrolujte jméno a heslo v nastavení doplňku.'))
        return

    shows = search_site(session, query)
    log("{0} page match(es) for '{1}'".format(len(shows), query))
    if not shows:
        return

    if season and season > 1:
        # season is known (from Kodi's playback metadata, or typed as
        # "S4" etc.) - each season is its own separate page here, so go
        # straight to it.
        target_title = "{0} S{1}".format(query, season)
        candidates = [pick_best_match(target_title, shows)]
    elif season == 1 or len(shows) == 1:
        # season 1 (or a standalone movie) has no "S<n>" suffix on this
        # site at all, and if only one page matched anyway there's
        # nothing to disambiguate.
        candidates = [pick_best_match(query, shows)]
    else:
        # season unknown and more than one page matched (e.g. typing a
        # bare title like "tensei" for a multi-season anime) - rather
        # than silently guessing one season via fuzzy match, list every
        # matching season/page and label each result with its page title
        # so the season is visible in Kodi's subtitle list.
        candidates = shows[:6]
        log("season unknown - showing all {0} matched page(s) instead of guessing".format(len(candidates)))

    allowed_langs = get_allowed_languages(params)
    if allowed_langs and LANG_NAME not in allowed_langs:
        log("Czech filtered out by Kodi's allowed-languages setting, nothing to show")
        return

    saved = {}
    shown = 0
    MAX_ITEMS = 60
    for show in candidates:
        if not show:
            continue
        rows = fetch_episode_links(session, show['url'])
        if not rows:
            log("no numbered episode links found on {0}".format(show['url']))
            continue

        if episode is not None:
            matching = [r for r in rows if r['ep'] == episode]
            if matching:
                rows = matching
            elif len(candidates) == 1:
                log("no row matched episode {0}, showing full list instead".format(episode))

        for row in rows:
            if shown >= MAX_ITEMS:
                break
            rid = str(len(saved))
            saved[rid] = row
            # Always put the show/season page's own title in the label -
            # even when only one page was searched - so it's never
            # ambiguous which season an episode belongs to.
            label = "{0} - {1}".format(show['title'], row['label'])
            append_subtitle(label, {"action": "download", "rid": rid})
            shown += 1
        if shown >= MAX_ITEMS:
            log("hit the {0}-item cap, stopping".format(MAX_ITEMS))
            break

    save_rows(saved)
    log("listed {0} subtitle(s) across {1} page(s)".format(shown, len(candidates)))


def handle_download(params):
    rid = params.get('rid', [None])[0]
    if rid is None:
        notify(L('Nothing to download.', 'Není co stáhnout.'))
        return
    rows = load_rows()
    row = rows.get(rid)
    if not row:
        notify(L('Subtitle info expired - please search again.', 'Údaje o titulcích vypršely - vyhledejte prosím znovu.'))
        return

    username = ADDON.getSetting('username')
    password = ADDON.getSetting('password')
    session = requests.Session()
    if not login(session, username, password):
        notify(L('Login failed - check username/password in addon settings.', 'Přihlášení selhalo - zkontrolujte jméno a heslo v nastavení doplňku.'))
        return

    try:
        resp = session.get(row['href'], headers=HEADERS, timeout=20)
        content = resp.content
        content_disposition = resp.headers.get('Content-Disposition', '')
    except Exception as e:
        log("download failed: {0}".format(e))
        notify(L('Download failed (see debug log).', 'Stažení selhalo (podrobnosti v logu).'))
        return

    if not content or content.lstrip()[:1] == b'<':
        notify(L('Download failed - unexpected response (see debug log). Try again in a moment.', 'Stažení selhalo - neočekávaná odpověď (podrobnosti v logu). Zkuste to za chvíli znovu.'))
        log("download got empty/HTML body for episode {0}".format(row.get('ep')))
        return

    if len(content) > MAX_DOWNLOAD_BYTES:
        notify(L('Download refused - file is larger than expected (see debug log).', 'Stažení odmítnuto - soubor je větší, než by měl být (podrobnosti v logu).'))
        log("download refused: {0} bytes exceeds MAX_DOWNLOAD_BYTES {1}".format(
            len(content), MAX_DOWNLOAD_BYTES))
        return

    safe_name = re.sub(r'[^\w]+', '_', str(row.get('label', row.get('ep', 'sub'))))
    is_zip = content[:2] == b'PK'

    if is_zip:
        zip_password = ADDON.getSetting('zip_password')

        zip_path = os.path.join(TEMP_DIR, "kamui_{0}_{1}.zip".format(safe_name, int(time.time())))
        try:
            with open(zip_path, 'wb') as f:
                f.write(content)
        except Exception as e:
            log("failed to write zip file: {0}".format(e))
            notify(L("Downloaded but couldn't save the file (see debug log).", 'Staženo, ale soubor se nepodařilo uložit (podrobnosti v logu).'))
            return

        extract_dir = os.path.join(TEMP_DIR, "kamui_{0}_{1}".format(safe_name, int(time.time())))
        try:
            _extract_zip(zip_path, extract_dir, zip_password)
        except ZipTooLargeError as e:
            notify(L('Download refused - archive is larger than expected when extracted (see debug log).', 'Stažení odmítnuto - archiv by byl po rozbalení příliš velký (podrobnosti v logu).'))
            log("refusing to extract {0}: {1}".format(zip_path, e))
            return
        except RuntimeError as e:
            log("zip extract failed - wrong/missing password: {0}".format(e))
            notify(L("This site's subtitle zips need a password - set it in the addon's settings.", 'ZIPy s titulky na tomto webu potřebují heslo - nastavte ho v nastavení doplňku.'))
            ADDON.openSettings()
            return
        except Exception as e:
            log("zip extract failed: {0}".format(e))
            notify(L("Downloaded a zip but couldn't extract it (see debug log).", 'ZIP se stáhl, ale nepodařilo se ho rozbalit (podrobnosti v logu).'))
            return

        sub_file = _find_subtitle_file(extract_dir)
        if not sub_file:
            # the zip might contain another zip one level down rather than
            # the subtitle directly - seen on some sites' download managers.
            nested_zip = _find_nested_zip(extract_dir)
            if nested_zip:
                log("no subtitle at top level, found nested zip {0}, extracting it too".format(nested_zip))
                try:
                    _extract_zip(nested_zip, extract_dir, zip_password)
                except Exception as e:
                    log("nested zip extract failed: {0}".format(e))
                sub_file = _find_subtitle_file(extract_dir)
        if not sub_file:
            all_files = []
            for root, _dirs, files in os.walk(extract_dir):
                for fn in files:
                    all_files.append(fn)
            notify(L('Downloaded and extracted, but no subtitle file found inside.', 'Staženo a rozbaleno, ale uvnitř nejsou žádné titulky.'))
            log("no subtitle file found after extracting {0}; zip contained: {1}".format(
                zip_path, all_files if all_files else "(nothing)"))
            return
        filepath = sub_file
    else:
        ext = guess_extension(content_disposition, content[:200])
        filename = "kamui_{0}_{1}{2}".format(safe_name, int(time.time()), ext)
        filepath = os.path.join(TEMP_DIR, filename)
        try:
            with open(filepath, 'wb') as f:
                f.write(content)
        except Exception as e:
            log("failed to write subtitle file: {0}".format(e))
            notify(L("Downloaded but couldn't save the file (see debug log).", 'Staženo, ale soubor se nepodařilo uložit (podrobnosti v logu).'))
            return

    remember_owner(filepath)

    log("saved subtitle to {0}".format(filepath))
    listitem = xbmcgui.ListItem(label=os.path.basename(filepath))
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=filepath, listitem=listitem, isFolder=False)


def run():
    try:
        cleanup_temp_dir()
        params = get_params()
        action = params.get('action', [''])[0]
        log("action={0} params={1}".format(action, params))
        if action == 'search':
            handle_search(params, is_manual=False)
        elif action == 'manualsearch':
            handle_search(params, is_manual=True)
        elif action == 'download':
            handle_download(params)
        else:
            log("unknown/missing action, nothing to do")
    except Exception as e:
        log("unhandled exception: {0}\n{1}".format(e, traceback.format_exc()))
    finally:
        xbmcplugin.endOfDirectory(HANDLE)


if __name__ == '__main__':
    run()
